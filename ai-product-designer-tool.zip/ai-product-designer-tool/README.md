# AI Product Designer Tool v0.4.3

社内ツール化を検討するための、Design Console 単体プレビューです。
Codex Skill の配布物ではありません。`SKILL.md`、Agent 定義、Skill 用の手順書は含めていません。

## 現在できること

- 構造ワイヤー、UI モックアップ、プロトタイプの画面遷移を確認
- 複数案を比較し、1案へまとめるフローを確認
- 構造ワイヤーの画面カード・遷移線を直接編集
- ファイルやフォルダを参考資料として一時添付
- ブラウザ内で一時保存・復元
- 成果物のプレビューとダウンロード
- AI API なしで、限定的なローカル編集命令を試す

## ローカルで起動

Python 3 と Node.js が必要です。展開したフォルダで次を実行します。

```bash
python3 scripts/design_console.py \
  --workspace "/path/to/design-workspace" \
  --port 4180
```

ブラウザで `http://127.0.0.1:4180/` を開きます。
作業データは指定した `design-workspace` に作成され、ツール本体とは分離されます。

## フォルダ構成

```text
ai-product-designer-tool-v0.4.3/
├── README.md
├── assets/
│   ├── design-console/   # ブラウザ画面
│   ├── wireframe-kit/    # 成果物生成用のローカル素材
│   └── workspace-seed/   # 初期設定
└── scripts/              # ローカルサーバーと必要な検証処理
```

## AI API 連携について

現在の `assets/design-console/ai-adapter.js` は、AI API 未接続のローカル動作確認用です。
会社で PAT を接続するときは、ブラウザ JavaScript に PAT を書かず、社内サーバー側の環境変数または Secret Manager に保管してください。

想定する構成:

```text
ブラウザ
  → 社内バックエンド
  → 会社の AI API
```

主な置き換え境界は `assets/design-console/ai-adapter.js` です。画面・フローマップ編集・成果物表示は維持し、AI リクエスト部分を社内バックエンドへ接続します。

構造ワイヤーの直接編集は、文言、画面位置、自動整列、矢印ラベル位置の調整を対象にしています。画面や遷移の追加・削除・接続先変更など、導線の意味を変える修正は、全体の整合性を保つためチャット／AI側で扱います。

## 注意

`scripts/design_console.py` はローカル検証用です。社内サーバーへ本番配置する際は、会社の標準基盤に合わせて認証、権限管理、複数ユーザー対応、監査ログ、保存期間、ファイル検査をバックエンドへ実装してください。
