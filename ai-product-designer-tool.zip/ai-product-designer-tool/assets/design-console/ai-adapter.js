/**
 * AI Product Designer adapter boundary.
 *
 * The company implementation only needs to replace this file (or assign the
 * same object before app.js loads). The bundled local mode keeps the complete
 * workflow testable without a PAT and applies a small deterministic set of
 * chat edits. Keep PATs and API secrets on the server.
 */
const localSessions = new Map();

window.AIProductDesignerAdapter = {
  mode: "local",

  async createSession(input) {
    await delay(350);
    const session = {
      id: crypto.randomUUID(),
      input,
      createdAt: new Date().toISOString(),
      usage: { totalTokens: 0 },
    };
    localSessions.set(session.id, session);
    return session;
  },

  async generate({ sessionId, phase, input, parentArtifact, selectedDirection }) {
    await delay(900);
    const inheritedFlowModel = parentArtifact?.flowModel || selectedDirection?.flowModel || null;
    const directionSeeds =
      phase === "wireframe"
        ? demoDirections(input)
        : [selectedDirection || demoDirections(input)[0]].filter(Boolean);
    const directions = directionSeeds.map((direction) => ({
      ...direction,
      flowModel:
        phase === "wireframe" && input.outputLevel === "structural-wireframe"
          ? direction.flowModel || demoFlowModel(input, direction.id)
          : inheritedFlowModel || direction.flowModel || demoFlowModel(input, direction.id),
    }));
    const isConsolidated = phase !== "wireframe" || directions.length === 1;
    const viewports = demoViewportSpecs(input);
    const activeDirection =
      directions.find((direction) => direction.id === selectedDirection?.id) ||
      directions[0] ||
      null;
    return {
      sessionId,
      usage: { totalTokens: 0 },
      artifact: {
        id: crypto.randomUUID(),
        phase,
        parentArtifactId: parentArtifact?.id || null,
        selectedDirectionId: activeDirection?.id || null,
        directions,
        isConsolidated,
        viewports: viewports.map(viewportMetadata),
        filename: `${slug(input.title)}-${phase}.html`,
        flowModel: activeDirection?.flowModel || null,
        prototypeBasePhase: parentArtifact?.phase || null,
        html: demoArtifactHtml({
          phase,
          input,
          model: activeDirection?.flowModel || null,
          prototypeBasePhase: parentArtifact?.phase || null,
          sourceFlowModel: parentArtifact?.flowModel || activeDirection?.flowModel || null,
        }),
      },
      message:
        phase === "wireframe"
          ? directions.length > 1
            ? `${directions.map((direction) => direction.label.split("：")[0]).join("と")}を用意しました。どれをベースにしますか？ 追加希望があればチャットで伝えてください。内容を詰めたあと、最終ワイヤーを1案にまとめます。`
            : "ワイヤーを1案作成しました。内容を確認し、このまま次のフェーズへ進めます。"
          : phase === "ui-mockup"
            ? `ワイヤーの情報構造を引き継ぎ、${viewportSummary(viewports)}のUIモックを並べて表示しました。再アップロードは不要です。`
            : `選定案の全画面と遷移を引き継ぎ、${viewportSummary(viewports)}のプロトタイプを表示しました。画面内の操作から遷移を確認できます。`,
    };
  },

  async sendMessage({ sessionId, message, phase, artifact, input: suppliedInput }) {
    await delay(500);
    const session = localSessions.get(sessionId);
    const input = session?.input || suppliedInput || {
      title: artifact?.flowModel?.title || "新しい制作",
      prompt: "",
      settings: {},
    };
    const sourceModel =
      artifact?.flowModel ||
      artifact?.directions?.find((direction) => direction.id === artifact.selectedDirectionId)?.flowModel ||
      null;
    if (!sourceModel) {
      return {
        message: "この成果物にはローカル編集用の画面構造がありません。前のワイヤーフェーズへ戻るか、成果物を再生成してください。",
        usage: { totalTokens: 0 },
      };
    }

    const revision = applyLocalRevision(sourceModel, message);
    if (!revision.changed) {
      return {
        message:
          "ローカルモードで解釈できる指示ではありませんでした。例：「画面2のタイトルを候補一覧にして」「『候補A』を『プランA』に変更」「確認画面を追加」「画面3を削除」「画面2から画面4へ『比較する』で遷移」。自由なデザイン判断はPAT接続後にAIへ渡します。",
        usage: { totalTokens: 0 },
      };
    }

    const directions = Array.isArray(artifact.directions)
      ? artifact.directions.map((direction) =>
          direction.id === artifact.selectedDirectionId
            ? { ...direction, flowModel: revision.model }
            : { ...direction },
        )
      : [];
    const revisedArtifact = {
      ...artifact,
      id: crypto.randomUUID(),
      parentArtifactId: artifact.id || null,
      flowModel: revision.model,
      directions,
      updatedAt: new Date().toISOString(),
      editedLocally: true,
    };
    revisedArtifact.html = demoArtifactHtml({
      phase,
      input,
      consolidated: Boolean(revisedArtifact.isConsolidated),
      model: revision.model,
      prototypeBasePhase: revisedArtifact.prototypeBasePhase || (phase === "prototype" ? "wireframe" : null),
      sourceFlowModel: revision.model,
    });
    return {
      artifact: revisedArtifact,
      message: `${revision.summary}。成果物へ反映しました。ローカル処理のためAIトークンは消費していません。`,
      usage: { totalTokens: 0 },
    };
  },

  async consolidate({ sessionId, input, artifact, selectedDirection }) {
    await delay(850);
    const viewports = demoViewportSpecs(input);
    const flowModel =
      selectedDirection.flowModel ||
      artifact?.flowModel ||
      demoFlowModel(input, selectedDirection.id);
    const consolidatedDirection = { ...selectedDirection, flowModel };
    return {
      sessionId,
      usage: { totalTokens: 0 },
      artifact: {
        id: crypto.randomUUID(),
        phase: "wireframe",
        parentArtifactId: artifact?.id || null,
        selectedDirectionId: selectedDirection.id,
        directions: [consolidatedDirection],
        isConsolidated: true,
        viewports: viewports.map(viewportMetadata),
        filename: `${slug(input.title)}-final-wireframe.html`,
        flowModel,
        html: demoArtifactHtml({
          phase: "wireframe",
          input,
          consolidated: true,
          model: flowModel,
        }),
      },
      message: `${selectedDirection.label}をベースに、ここまでの会話を反映した最終ワイヤーへ一本化しました。内容を確認し、必要ならチャットで調整してください。問題なければ次のフェーズへ進めます。`,
    };
  },
};

function applyLocalRevision(sourceModel, rawMessage) {
  const model = cloneValue(sourceModel);
  const message = String(rawMessage || "").trim();
  const changes = [];

  const quotedReplacement = message.match(/[「『"](.+?)[」』"]\s*を\s*[「『"](.+?)[」』"]\s*(?:に|へ)?(?:変更|修正|置換|して)/);
  if (quotedReplacement) {
    const [, before, after] = quotedReplacement;
    let replacements = 0;
    model.title = replaceText(model.title, before, after, () => replacements += 1);
    for (const screen of model.screens) {
      screen.title = replaceText(screen.title, before, after, () => replacements += 1);
      screen.eyebrow = replaceText(screen.eyebrow, before, after, () => replacements += 1);
      screen.body = replaceText(screen.body, before, escapeHtmlText(after), () => replacements += 1);
    }
    for (const edge of model.edges) {
      edge.label = replaceText(edge.label, before, after, () => replacements += 1);
    }
    if (replacements) changes.push(`「${before}」を「${after}」へ${replacements}か所変更`);
  }

  const projectTitle = message.match(/(?:案件|プロジェクト|成果物)(?:の)?タイトルを\s*[「『"]?(.+?)[」』"]?\s*(?:に|へ)?(?:変更|修正|して|$)/);
  if (projectTitle?.[1]) {
    model.title = cleanInstructionValue(projectTitle[1]);
    changes.push(`案件タイトルを「${model.title}」へ変更`);
  }

  const screenTitle = message.match(/画面\s*(\d+)\s*の(?:タイトル|画面名|名前)を\s*[「『"]?(.+?)[」』"]?\s*(?:に|へ)?(?:変更|修正|して|$)/);
  if (screenTitle) {
    const screen = model.screens[Number(screenTitle[1]) - 1];
    if (screen) {
      screen.title = cleanInstructionValue(screenTitle[2]);
      changes.push(`画面${screenTitle[1]}のタイトルを「${screen.title}」へ変更`);
    }
  }

  const screenLead = message.match(/画面\s*(\d+)\s*の(?:説明|本文|リード)を\s*[「『"]?(.+?)[」』"]?\s*(?:に|へ)?(?:変更|修正|して|$)/);
  if (screenLead) {
    const screen = model.screens[Number(screenLead[1]) - 1];
    if (screen) {
      const value = cleanInstructionValue(screenLead[2]);
      screen.body = replaceScreenLead(screen.body, value);
      changes.push(`画面${screenLead[1]}の説明を変更`);
    }
  }

  const addScreen =
    message.match(/[「『"]?([^「『」』"\n]{1,40})[」』"]?(?:という|の)?画面を追加/) ||
    message.match(/画面を追加\s*[:：]?\s*[「『"]?(.+?)[」』"]?$/);
  if (addScreen?.[1]) {
    const title = cleanInstructionValue(addScreen[1]).replace(/^新しい/, "") || "新しい画面";
    const previous = model.screens.at(-1);
    const index = model.screens.length;
    const id = uniqueModelId(model, `local-screen-${index + 1}`);
    model.screens.push({
      id,
      x: Math.max(110, Number(previous?.x || 110) + 360),
      y: Number(previous?.y || 300),
      title,
      eyebrow: `SCREEN ${String(index + 1).padStart(2, "0")}`,
      body: `<p class="screen-lead" data-editable>${escapeHtmlText(title)}で必要な情報と操作を確認</p><div class="image-skeleton"><span>画像 4:3</span></div><div class="wire-field" data-editable>必要な情報</div><button class="wire-button" type="button" data-editable>次へ進む</button>`,
    });
    if (previous) {
      model.edges.push({
        id: uniqueModelId(model, `local-edge-${model.edges.length + 1}`),
        from: previous.id,
        to: id,
        label: `${title}へ`,
        lineStyle: "solid",
        arrowDirection: "forward",
        fromSide: "right",
        toSide: "left",
      });
    }
    normalizeScreenEyebrows(model.screens);
    changes.push(`「${title}」画面を追加`);
  }

  const deleteScreen = message.match(/画面\s*(\d+)\s*を削除/);
  if (deleteScreen && model.screens.length > 1) {
    const index = Number(deleteScreen[1]) - 1;
    const [removed] = index >= 0 ? model.screens.splice(index, 1) : [];
    if (removed) {
      model.edges = model.edges.filter((edge) => edge.from !== removed.id && edge.to !== removed.id);
      normalizeScreenEyebrows(model.screens);
      changes.push(`画面${deleteScreen[1]}「${removed.title}」を削除`);
    }
  }

  const addTransition = message.match(/画面\s*(\d+)\s*から\s*画面\s*(\d+)\s*へ(?:[「『"](.+?)[」』"](?:で|という)?)?遷移/);
  if (addTransition) {
    const from = model.screens[Number(addTransition[1]) - 1];
    const to = model.screens[Number(addTransition[2]) - 1];
    if (from && to) {
      const label = addTransition[3] || `${to.title}へ`;
      model.edges.push({
        id: uniqueModelId(model, `local-edge-${model.edges.length + 1}`),
        from: from.id,
        to: to.id,
        label,
        lineStyle: "solid",
        arrowDirection: "forward",
        fromSide: from.x <= to.x ? "right" : "left",
        toSide: from.x <= to.x ? "left" : "right",
      });
      changes.push(`画面${addTransition[1]}から画面${addTransition[2]}への遷移を追加`);
    }
  }

  return {
    changed: changes.length > 0,
    model,
    summary: changes.join("、"),
  };
}

function replaceText(value, before, after, onReplace) {
  const source = String(value || "");
  const count = source.split(before).length - 1;
  if (!count) return value;
  for (let index = 0; index < count; index += 1) onReplace();
  return source.replaceAll(before, after);
}

function replaceScreenLead(body, value) {
  const safeValue = escapeHtmlText(value);
  if (/<p class="screen-lead"[^>]*>.*?<\/p>/s.test(body)) {
    return body.replace(/<p class="screen-lead"([^>]*)>.*?<\/p>/s, `<p class="screen-lead"$1>${safeValue}</p>`);
  }
  return `<p class="screen-lead" data-editable>${safeValue}</p>${body}`;
}

function cleanInstructionValue(value) {
  return String(value || "")
    .trim()
    .replace(/[」』"]$/, "")
    .replace(/\s*(?:に|へ)?(?:変更|修正|して)$/, "")
    .trim();
}

function normalizeScreenEyebrows(screens) {
  screens.forEach((screen, index) => {
    screen.eyebrow = index === 0 ? "START" : index === screens.length - 1 ? "GOAL" : `SCREEN ${String(index + 1).padStart(2, "0")}`;
  });
}

function uniqueModelId(model, base) {
  const ids = new Set([
    ...model.screens.map((screen) => screen.id),
    ...model.edges.map((edge) => edge.id),
  ]);
  let candidate = base;
  let suffix = 2;
  while (ids.has(candidate)) candidate = `${base}-${suffix++}`;
  return candidate;
}

function cloneValue(value) {
  return typeof structuredClone === "function"
    ? structuredClone(value)
    : JSON.parse(JSON.stringify(value));
}

function escapeHtmlText(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");
}

function delay(milliseconds) {
  return new Promise((resolve) => window.setTimeout(resolve, milliseconds));
}

function slug(value) {
  return String(value || "design")
    .normalize("NFKC")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 42) || "design";
}

function demoDirections(input) {
  const labels = [
    "1a：条件照合",
    "1b：比較ボード",
    "1c：共有ノート",
    "1d：段階選択",
    "1e：AIガイド",
  ];
  const count = Math.max(1, Math.min(5, Number(input.settings?.compareDirections || 1)));
  return labels.slice(0, count).map((label, index) => ({
    id: `direction-${String.fromCharCode(97 + index)}`,
    label,
  }));
}

function demoFlowModel(input, directionId = "direction-a") {
  const title = input.title || "新しい制作";
  const shared = {
    version: 2,
    title,
    directionId,
  };
  const models = {
    "direction-a": {
      directionLabel: "1a：条件照合",
      screens: [
        {
          id: "a-conditions",
          x: 110,
          y: 300,
          title: "検索条件",
          eyebrow: "START",
          body: '<p class="screen-lead" data-editable>希望条件を入力して候補を探す</p><div class="wire-field" data-editable>エリア・日付・人数</div><div class="wire-field" data-editable>予算・移動時間</div><button class="wire-button" type="button" data-editable>候補を検索</button>',
        },
        {
          id: "a-results",
          x: 470,
          y: 300,
          title: "条件照合一覧",
          eyebrow: "SCREEN 02",
          body: '<p class="screen-lead" data-editable>候補ごとの一致・不足を先に比べる</p><div class="image-skeleton"><span>画像 4:3</span></div><div class="wire-row"><strong data-editable>候補A</strong><span data-editable>一致 4/5</span></div><div class="wire-row"><strong data-editable>候補B</strong><span data-editable>一致 3/5</span></div>',
        },
        {
          id: "a-detail",
          x: 830,
          y: 100,
          title: "一致理由",
          eyebrow: "SCREEN 03",
          body: '<p class="screen-lead" data-editable>合う理由と確認が必要な点を理解</p><div class="image-skeleton"><span>画像 16:9</span></div><div class="wire-note" data-editable>移動が短く予算内。混雑状況は未確認です</div><button class="wire-button" type="button" data-editable>比較に追加</button>',
        },
        {
          id: "a-compare",
          x: 830,
          y: 560,
          title: "条件別比較",
          eyebrow: "SCREEN 04",
          body: '<p class="screen-lead" data-editable>同じ希望条件の順序で違いを判断</p><div class="wire-compare"><span data-editable>価格</span><strong data-editable>A ¥8,400</strong></div><div class="wire-compare"><span data-editable>移動</span><strong data-editable>A 8分</strong></div><div class="wire-compare"><span data-editable>家族の希望</span><strong data-editable>2票</strong></div>',
        },
        {
          id: "a-decision",
          x: 1190,
          y: 300,
          title: "候補を決定",
          eyebrow: "GOAL",
          body: '<p class="screen-lead" data-editable>選定理由を残して候補を決める</p><div class="wire-note" data-editable>候補A：条件4件に一致</div><div class="wire-field" data-editable>決定メモを追加</div><button class="wire-button" type="button" data-editable>この候補に決める</button>',
        },
      ],
      edges: [
        { id: "a-edge-1", from: "a-conditions", to: "a-results", label: "照合する", type: "action" },
        { id: "a-edge-2", from: "a-results", to: "a-detail", label: "理由を見る", type: "action" },
        { id: "a-edge-3", from: "a-results", to: "a-compare", label: "並べて比べる", type: "action" },
        { id: "a-edge-4", from: "a-detail", to: "a-compare", label: "比較へ追加", type: "action" },
        { id: "a-edge-5", from: "a-compare", to: "a-decision", label: "候補を決める", type: "action" },
        { id: "a-edge-6", from: "a-decision", to: "a-results", label: "条件を見直す", type: "back" },
      ],
    },
    "direction-b": {
      directionLabel: "1b：比較ボード",
      screens: [
        {
          id: "b-conditions",
          x: 110,
          y: 300,
          title: "比較条件",
          eyebrow: "START",
          body: '<p class="screen-lead" data-editable>比較したい条件と優先順位を決める</p><div class="wire-field" data-editable>絶対条件</div><div class="wire-field" data-editable>できれば満たしたい条件</div><button class="wire-button" type="button" data-editable>ボードを作る</button>',
        },
        {
          id: "b-board",
          x: 470,
          y: 300,
          title: "比較ボード",
          eyebrow: "SCREEN 02",
          body: '<p class="screen-lead" data-editable>候補を横並びにして比較軸ごとに確認</p><div class="wire-compare"><span data-editable>候補A</span><strong data-editable>4項目一致</strong></div><div class="wire-compare"><span data-editable>候補B</span><strong data-editable>3項目一致</strong></div><div class="wire-compare"><span data-editable>候補C</span><strong data-editable>価格優先</strong></div>',
        },
        {
          id: "b-candidate",
          x: 830,
          y: 100,
          title: "候補詳細",
          eyebrow: "SCREEN 03",
          body: '<p class="screen-lead" data-editable>ボード上の候補を詳しく確認</p><div class="image-skeleton"><span>画像 16:9</span></div><div class="wire-note" data-editable>口コミ・アクセス・キャンセル条件</div><button class="wire-button" type="button" data-editable>ボードへ戻る</button>',
        },
        {
          id: "b-shortlist",
          x: 830,
          y: 560,
          title: "最終候補",
          eyebrow: "SCREEN 04",
          body: '<p class="screen-lead" data-editable>残した2件だけを最終比較</p><div class="wire-row"><strong data-editable>候補A</strong><span data-editable>総合1位</span></div><div class="wire-row"><strong data-editable>候補C</strong><span data-editable>価格1位</span></div><div class="wire-field" data-editable>迷っている点をメモ</div>',
        },
        {
          id: "b-decision",
          x: 1190,
          y: 300,
          title: "比較結果",
          eyebrow: "GOAL",
          body: '<p class="screen-lead" data-editable>比較表と決定理由を保存</p><div class="wire-note" data-editable>候補Aを選択：移動と設備を優先</div><button class="wire-button" type="button" data-editable>比較結果を保存</button>',
        },
      ],
      edges: [
        { id: "b-edge-1", from: "b-conditions", to: "b-board", label: "ボードを作る", type: "action" },
        { id: "b-edge-2", from: "b-board", to: "b-candidate", label: "詳細を見る", type: "action" },
        { id: "b-edge-3", from: "b-candidate", to: "b-board", label: "比較へ戻る", type: "back" },
        { id: "b-edge-4", from: "b-board", to: "b-shortlist", label: "2件に絞る", type: "action" },
        { id: "b-edge-5", from: "b-shortlist", to: "b-decision", label: "最終決定", type: "action" },
      ],
    },
    "direction-c": {
      directionLabel: "1c：共有ノート",
      screens: [
        {
          id: "c-search",
          x: 110,
          y: 300,
          title: "候補を探す",
          eyebrow: "START",
          body: '<p class="screen-lead" data-editable>気になる候補を見つけてノートへ追加</p><div class="wire-field" data-editable>エリア・日付・人数</div><div class="image-skeleton"><span>候補画像 4:3</span></div><button class="wire-button" type="button" data-editable>ノートに追加</button>',
        },
        {
          id: "c-note",
          x: 470,
          y: 300,
          title: "共有ノート",
          eyebrow: "SCREEN 02",
          body: '<p class="screen-lead" data-editable>候補と会話の成果を1か所に集約</p><div class="wire-row"><strong data-editable>候補A</strong><span data-editable>父が追加</span></div><div class="wire-row"><strong data-editable>候補B</strong><span data-editable>母が追加</span></div><div class="wire-field" data-editable>コメントを書く</div>',
        },
        {
          id: "c-share",
          x: 830,
          y: 100,
          title: "家族へ共有",
          eyebrow: "SCREEN 03",
          body: '<p class="screen-lead" data-editable>リンクで招待し、希望を集める</p><div class="wire-field" data-editable>共有相手を追加</div><div class="wire-note" data-editable>行きたい候補に○、迷う候補に△</div><button class="wire-button" type="button" data-editable>共有リンクを送る</button>',
        },
        {
          id: "c-vote",
          x: 830,
          y: 560,
          title: "投票・相談",
          eyebrow: "SCREEN 04",
          body: '<p class="screen-lead" data-editable>家族の投票とコメントを同時に確認</p><div class="wire-compare"><span data-editable>候補A</span><strong data-editable>○ 2 / △ 1</strong></div><div class="wire-compare"><span data-editable>候補B</span><strong data-editable>○ 1 / △ 2</strong></div><div class="wire-note" data-editable>妹：デザートがある方がいい</div>',
        },
        {
          id: "c-plan",
          x: 1190,
          y: 300,
          title: "予定を確定",
          eyebrow: "GOAL",
          body: '<p class="screen-lead" data-editable>決定内容と理由をノートに残す</p><div class="wire-note" data-editable>候補Aに決定・集合は10:00</div><button class="wire-button" type="button" data-editable>予定として保存</button>',
        },
      ],
      edges: [
        { id: "c-edge-1", from: "c-search", to: "c-note", label: "ノートに追加", type: "action" },
        { id: "c-edge-2", from: "c-note", to: "c-share", label: "家族へ共有", type: "action" },
        { id: "c-edge-3", from: "c-share", to: "c-vote", label: "回答を集める", type: "action" },
        { id: "c-edge-4", from: "c-vote", to: "c-note", label: "候補を見直す", type: "back" },
        { id: "c-edge-5", from: "c-vote", to: "c-plan", label: "予定を決める", type: "action" },
      ],
    },
    "direction-d": {
      directionLabel: "1d：段階選択",
      screens: [
        {
          id: "d-start",
          x: 110,
          y: 300,
          title: "最優先を選ぶ",
          eyebrow: "START",
          body: '<p class="screen-lead" data-editable>最初に重視する条件を1つだけ選ぶ</p><div class="wire-field" data-editable>近さ / 価格 / 過ごし方</div><button class="wire-button" type="button" data-editable>候補を見る</button>',
        },
        {
          id: "d-rough",
          x: 470,
          y: 300,
          title: "大きく絞る",
          eyebrow: "SCREEN 02",
          body: '<p class="screen-lead" data-editable>最優先条件で候補を3件に絞る</p><div class="image-skeleton"><span>候補画像 4:3</span></div><div class="wire-row"><strong data-editable>候補A</strong><span data-editable>近さ◎</span></div><div class="wire-row"><strong data-editable>候補B</strong><span data-editable>価格◎</span></div>',
        },
        {
          id: "d-refine",
          x: 830,
          y: 300,
          title: "追加条件で絞る",
          eyebrow: "SCREEN 03",
          body: '<p class="screen-lead" data-editable>次に気になる条件だけを追加</p><div class="wire-field" data-editable>食事 / 混雑 / 設備</div><div class="wire-note" data-editable>残り2件</div><button class="wire-button" type="button" data-editable>最終確認へ</button>',
        },
        {
          id: "d-decision",
          x: 1190,
          y: 300,
          title: "最終確認",
          eyebrow: "GOAL",
          body: '<p class="screen-lead" data-editable>段階ごとの選択理由を確認して決定</p><div class="wire-note" data-editable>近さ → 食事 → 混雑で候補A</div><button class="wire-button" type="button" data-editable>この候補に決める</button>',
        },
      ],
      edges: [
        { id: "d-edge-1", from: "d-start", to: "d-rough", label: "まず絞る", type: "action" },
        { id: "d-edge-2", from: "d-rough", to: "d-refine", label: "条件を追加", type: "action" },
        { id: "d-edge-3", from: "d-refine", to: "d-decision", label: "決定する", type: "action" },
        { id: "d-edge-4", from: "d-refine", to: "d-rough", label: "絞り直す", type: "back" },
      ],
    },
    "direction-e": {
      directionLabel: "1e：AIガイド",
      screens: [
        {
          id: "e-request",
          x: 110,
          y: 300,
          title: "希望を伝える",
          eyebrow: "START",
          body: '<p class="screen-lead" data-editable>自然な言葉で今回のおでかけを相談</p><div class="wire-note" data-editable>子どもが楽しめて移動が少ない場所</div><button class="wire-button" type="button" data-editable>AIに相談</button>',
        },
        {
          id: "e-question",
          x: 470,
          y: 300,
          title: "追加質問",
          eyebrow: "SCREEN 02",
          body: '<p class="screen-lead" data-editable>判断に必要な不足条件だけを確認</p><div class="wire-field" data-editable>予算の上限は？</div><div class="wire-field" data-editable>屋外でもよい？</div><button class="wire-button" type="button" data-editable>回答する</button>',
        },
        {
          id: "e-proposal",
          x: 830,
          y: 300,
          title: "おすすめ提案",
          eyebrow: "SCREEN 03",
          body: '<p class="screen-lead" data-editable>条件と理由を添えて3件を提案</p><div class="image-skeleton"><span>提案画像 4:3</span></div><div class="wire-note" data-editable>候補A：移動8分、雨でも安心</div><button class="wire-button" type="button" data-editable>詳しく聞く</button>',
        },
        {
          id: "e-plan",
          x: 1190,
          y: 300,
          title: "プラン確定",
          eyebrow: "GOAL",
          body: '<p class="screen-lead" data-editable>選んだ候補を当日の予定へ整える</p><div class="wire-note" data-editable>10:00集合 → 昼食 → 体験</div><button class="wire-button" type="button" data-editable>予定として保存</button>',
        },
      ],
      edges: [
        { id: "e-edge-1", from: "e-request", to: "e-question", label: "不足を確認", type: "action" },
        { id: "e-edge-2", from: "e-question", to: "e-proposal", label: "提案を見る", type: "action" },
        { id: "e-edge-3", from: "e-proposal", to: "e-plan", label: "候補を選ぶ", type: "action" },
        { id: "e-edge-4", from: "e-proposal", to: "e-question", label: "条件を変える", type: "back" },
      ],
    },
  };
  const selected = models[directionId] || models["direction-a"];
  return {
    ...shared,
    directionLabel: selected.directionLabel,
    screens: selected.screens.map((screen) => ({ ...screen })),
    edges: selected.edges.map((edge) => ({ ...edge })),
  };
}

function demoViewportSpecs(input) {
  const selected = Array.isArray(input.settings?.viewports) && input.settings.viewports.length
    ? input.settings.viewports
    : ["1440x1000"];
  const selectedCount = selected.length;
  return selected.map((value, index) => {
    const match = String(value).match(/^(\d+)x(\d+)$/);
    const width = match ? Number(match[1]) : 1440;
    const height = match ? Number(match[2]) : 1000;
    const kind = width <= 480 ? "mobile" : width <= 900 ? "tablet" : "desktop";
    const label = kind === "mobile" ? "モバイル" : kind === "tablet" ? "タブレット" : "デスクトップ";
    const scale =
      selectedCount >= 3
        ? kind === "mobile"
          ? 0.48
          : kind === "tablet"
            ? 0.3
            : 0.24
        : selectedCount === 2
          ? kind === "mobile"
            ? 0.62
            : kind === "tablet"
              ? 0.42
              : 0.36
          : kind === "mobile"
            ? 0.86
            : kind === "tablet"
              ? 0.68
              : 0.62;
    const focusScale = 1;
    return {
      id: `${kind}-${index + 1}`,
      kind,
      label,
      width,
      height,
      scale,
      focusScale,
    };
  });
}

function viewportMetadata(viewport) {
  return {
    id: viewport.id,
    kind: viewport.kind,
    label: viewport.label,
    width: viewport.width,
    height: viewport.height,
  };
}

function viewportSummary(viewports) {
  return viewports.map((viewport) => `${viewport.label} ${viewport.width}×${viewport.height}`).join("、");
}

function demoUiMockScreenHtml({ input, viewport, screen, index }) {
  const safeTitle = escapeMarkup(input.title);
  return `<!doctype html>
<html lang="ja">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${safeTitle} — ${escapeMarkup(screen.title)}</title>
  <style>
    :root{font-family:"Hiragino Sans","Yu Gothic",system-ui,sans-serif;color:#1f2530;background:#f7f8fb}
    *{box-sizing:border-box}body{min-height:100vh;margin:0;background:#f7f8fb}button{font:inherit}
    .mock-screen{min-height:100vh;padding:clamp(22px,4vw,56px)}
    .mock-shell{width:min(100%,820px);margin:auto;padding:clamp(22px,4vw,44px);background:#fff;border:1px solid #dce1eb;border-radius:22px;box-shadow:0 18px 46px rgba(35,53,91,.10)}
    .mock-header{padding-bottom:20px;border-bottom:1px solid #e2e6ee}.mock-header p{margin:0 0 7px;color:#315efb;font-size:11px;font-weight:700;letter-spacing:.08em}.mock-header h1{margin:0;font-size:clamp(27px,4vw,44px);line-height:1.2}
    .screen-card-body{display:grid;gap:13px;padding-top:24px}.screen-lead{margin:0;color:#363d4a;font-size:clamp(15px,2vw,20px);line-height:1.6}
    .wire-field,.wire-note,.wire-row,.wire-compare{padding:13px 15px;background:#f7f8fb;border:1px solid #d8deea;border-radius:12px;font-size:14px}.wire-field{color:#697386}.wire-note{line-height:1.6}.wire-row,.wire-compare{display:flex;justify-content:space-between;gap:10px}
    .wire-button{min-height:46px;padding:0 17px;color:#fff;background:#315efb;border:0;border-radius:11px;font-size:14px;font-weight:500}
    .image-skeleton{display:grid;place-items:center;aspect-ratio:4/3;color:#697386;background:repeating-linear-gradient(135deg,#edf0f6,#edf0f6 11px,#f7f8fb 11px,#f7f8fb 22px);border:1px solid #d8deea;border-radius:14px;font-size:12px}
    @media(max-width:620px){.mock-screen{padding:14px}.mock-shell{padding:20px;border-radius:17px}.mock-header h1{font-size:29px}.screen-card-body{gap:10px}.wire-field,.wire-note,.wire-row,.wire-compare{font-size:12px}}
  </style>
</head>
<body>
  <main class="mock-screen">
    <article class="mock-shell">
      <header class="mock-header"><p>${escapeMarkup(screen.eyebrow || `SCREEN ${index + 1}`)} · UI MOCKUP</p><h1>${escapeMarkup(screen.title)}</h1></header>
      <div class="screen-card-body">${screen.body || ""}</div>
    </article>
  </main>
</body>
</html>`;
}

function demoUiMockupBoardHtml({ input, model }) {
  const safeTitle = escapeMarkup(input.title);
  const viewports = demoViewportSpecs(input);
  const screens = Array.isArray(model?.screens) && model.screens.length
    ? model.screens
    : demoFlowModel(input, "direction-a").screens;
  const groups = viewports
    .map((viewport) => {
      const scale = viewport.kind === "mobile" ? 0.48 : viewport.kind === "tablet" ? 0.32 : 0.24;
      const cards = screens
        .map((screen, index) => {
          const html = demoUiMockScreenHtml({ input, viewport, screen, index });
          return `
            <article class="mock-device" style="--device-width:${viewport.width}px;--device-height:${viewport.height}px;--scale:${scale};--stage-width:${Math.round(viewport.width * scale)}px;--stage-height:${Math.round(viewport.height * scale)}px">
              <header><span>${String(index + 1).padStart(2, "0")}</span><strong>${escapeMarkup(screen.title)}</strong></header>
              <div class="mock-stage"><iframe title="${escapeMarkup(screen.title)}・${viewport.label}" srcdoc="${escapeAttribute(html)}"></iframe></div>
            </article>
          `;
        })
        .join("");
      return `
        <section class="viewport-group">
          <header class="viewport-header"><div><p>${viewport.label}</p><h2>${viewport.width} × ${viewport.height}</h2></div><span>${screens.length}画面</span></header>
          <div class="mock-screens">${cards}</div>
        </section>
      `;
    })
    .join("");

  return `<!doctype html>
<html lang="ja">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${safeTitle} — UI Mockup</title>
  <style>
    :root{font-family:"Hiragino Sans","Yu Gothic",system-ui,sans-serif;color:#202020;background:#f8f7f4}
    *{box-sizing:border-box}body{margin:0}.mock-board{min-height:100vh;padding:26px}
    .board-header{display:flex;justify-content:space-between;gap:24px;align-items:end;margin-bottom:28px}.board-header p,.viewport-header p{margin:0 0 6px;color:#315efb;font-size:10px;font-weight:700;letter-spacing:.08em}.board-header h1{margin:0;font-size:24px}.board-header span{color:#6f6b65;font-size:11px}
    .viewport-group{margin-top:24px;padding:20px;background:#fff;border:1px solid #d9d6d0;border-radius:16px}.viewport-header{display:flex;justify-content:space-between;gap:20px;align-items:end;margin-bottom:16px}.viewport-header h2{margin:0;font-size:17px}.viewport-header>span{color:#6f6b65;font-size:10px}
    .mock-screens{display:flex;flex-wrap:wrap;gap:22px 18px;align-items:flex-start;padding:0 0 14px}.mock-device{flex:0 0 auto}.mock-device>header{display:flex;gap:8px;align-items:center;margin-bottom:8px;font-size:10px}.mock-device>header span{display:grid;place-items:center;width:22px;height:22px;color:#fff;background:#202020;border-radius:99px}.mock-device>header strong{font-size:11px}
    .mock-stage{width:var(--stage-width);height:var(--stage-height);overflow:hidden;background:#fff;border:1px solid #bcb8b1;border-radius:10px;box-shadow:0 8px 20px rgba(35,32,28,.08)}.mock-stage iframe{display:block;width:var(--device-width);height:var(--device-height);border:0;pointer-events:none;zoom:var(--scale)}
    .board-note{margin:24px 0 0;padding:13px 15px;color:#686868;background:#fff;border:1px dashed #aaa6a0;border-radius:11px;font-size:11px;line-height:1.6}
    @media(max-width:680px){.mock-board{padding:16px}.board-header{align-items:start;flex-direction:column}.viewport-group{padding:14px}}
  </style>
</head>
<body>
  <main class="mock-board">
    <header class="board-header"><div><p>UI MOCKUP · ALL SCREENS</p><h1>${safeTitle}</h1></div><span>${screens.length}画面 × ${viewports.length} viewport</span></header>
    ${groups}
    <p class="board-note">UIモックは操作用ではなく、画面構成と視覚表現を全画面まとめて確認するレビュー成果物です。操作確認は次のプロトタイプで行います。</p>
  </main>
</body>
</html>`;
}

function demoArtifactHtml({
  phase,
  input,
  consolidated = false,
  model = null,
  prototypeBasePhase = null,
  sourceFlowModel = null,
}) {
  if (phase === "wireframe" && input.outputLevel === "structural-wireframe") {
    return demoStructuralFlowHtml({ input, consolidated, model });
  }
  if (phase === "ui-mockup") {
    return demoUiMockupBoardHtml({ input, model: sourceFlowModel || model });
  }

  const safeTitle = escapeMarkup(input.title);
  const safePrompt = escapeMarkup(input.prompt);
  const isWireframe = phase === "wireframe";
  const isStructural = isWireframe && input.outputLevel === "structural-wireframe";
  const isPrototype = phase === "prototype";
  const viewports = demoViewportSpecs(input);
  const artifactLabel = isWireframe
    ? consolidated
      ? "FINAL WIREFRAME"
      : "WIREFRAME OPTIONS"
    : isPrototype
      ? "INTERACTIVE PROTOTYPE"
      : "UI MOCKUP";
  const deviceCards = viewports
    .map((viewport) => {
      const screenHtml = demoScreenHtml({
        phase,
        input,
        viewport,
        consolidated,
        prototypeBasePhase,
        sourceFlowModel,
      });
      const scaledWidth = Math.round(viewport.width * viewport.scale);
      const scaledHeight = Math.round(viewport.height * viewport.scale);
      const focusWidth = Math.round(viewport.width * viewport.focusScale);
      const focusHeight = Math.round(viewport.height * viewport.focusScale);
      return `
        <article class="device-card" data-device="${viewport.id}" style="
          --device-width:${viewport.width}px;
          --device-height:${viewport.height}px;
          --scale:${viewport.scale};
          --focus-scale:${viewport.focusScale};
          --stage-width:${scaledWidth}px;
          --stage-height:${scaledHeight}px;
          --focus-stage-width:${focusWidth}px;
          --focus-stage-height:${focusHeight}px;
        ">
          <header class="device-header">
            <div><strong>${viewport.label}</strong><span>${viewport.width} × ${viewport.height}</span></div>
            <button
              type="button"
              data-focus-device="${viewport.id}"
              data-default-label="${isPrototype ? "拡大して操作" : "拡大"}"
              aria-label="${viewport.label}を拡大表示"
            >${isPrototype ? "拡大して操作" : "拡大"}</button>
          </header>
          <div class="device-stage">
            <iframe
              title="${viewport.label} ${viewport.width}×${viewport.height} のプレビュー"
              sandbox="allow-scripts allow-forms"
              srcdoc="${escapeAttribute(screenHtml)}"
            ></iframe>
          </div>
        </article>
      `;
    })
    .join("");

  return `<!doctype html>
<html lang="ja">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${safeTitle}</title>
  <style>
    :root{font-family:"Hiragino Sans","Yu Gothic",system-ui,sans-serif;color:#202020;background:#f8f7f4}
    *{box-sizing:border-box}body{margin:0}button{font:inherit}.review-board{min-height:100vh;padding:24px}
    .board-header{display:flex;justify-content:space-between;gap:24px;align-items:end;margin:0 0 20px;padding:0 2px}
    .board-header p{margin:0 0 7px;color:#686868;font-size:10px;font-weight:700;letter-spacing:.08em}.board-header h1{margin:0;font-size:22px;line-height:1.25}
    .board-meta{color:#73716d;font-size:11px;text-align:right}.devices{display:flex;gap:22px;align-items:flex-start;overflow-x:auto;padding:0 2px 22px;scrollbar-gutter:stable}
    .device-card{--active-scale:var(--scale);--active-width:var(--stage-width);--active-height:var(--stage-height);flex:0 0 auto;padding:12px;background:#fff;border:1px solid #d3d0ca;border-radius:16px;box-shadow:0 10px 30px rgba(35,32,28,.08)}
    .device-header{display:flex;justify-content:space-between;gap:16px;align-items:center;margin-bottom:10px}.device-header strong,.device-header span{display:block}.device-header strong{font-size:12px}.device-header span{margin-top:2px;color:#777;font-size:9px}
    .device-header button{min-height:30px;padding:0 10px;color:#45433f;background:#f8f7f4;border:1px solid #d7d3cc;border-radius:8px;font-size:9px;font-weight:600}
    .device-stage{width:var(--active-width);height:var(--active-height);overflow:hidden;background:#fff;border:1px solid #bab7b1;border-radius:10px;transition:width .2s ease,height .2s ease}
    .device-stage iframe{display:block;width:var(--device-width);height:var(--device-height);border:0;zoom:var(--active-scale)}
    .device-card:not(.is-focused) .device-stage iframe{pointer-events:none}
    .device-card.is-focused{--active-scale:var(--focus-scale);--active-width:var(--focus-stage-width);--active-height:var(--focus-stage-height)}
    .review-board.has-focus .device-card:not(.is-focused){display:none}.review-board.has-focus .devices{overflow:visible}.review-board.has-focus .device-card{margin:auto}
    .board-note{margin:0 2px;padding:12px 14px;color:#686868;background:#f7f6f3;border:1px solid #d7d3cc;border-radius:10px;font-size:10px;line-height:1.6}
    @media(max-width:680px){.review-board{padding:16px}.board-header{align-items:start;flex-direction:column}.board-meta{text-align:left}.devices{gap:14px}}
  </style>
</head>
<body>
  <main class="review-board" id="review-board">
    <header class="board-header">
      <div><p>${artifactLabel} · SAMPLE</p><h1>${safeTitle}</h1></div>
      <div class="board-meta">${viewports.length} viewport${viewports.length > 1 ? "s" : ""}<br>${escapeMarkup(viewportSummary(viewports))}</div>
    </header>
    <section class="devices" aria-label="デバイス別プレビュー">
      ${deviceCards}
    </section>
    <p class="board-note">各画面は指定された実寸viewportで描画しています。「拡大」で単独表示に切り替えられます。${safePrompt}</p>
  </main>
  <script>
    const board = document.querySelector('#review-board');
    document.querySelectorAll('[data-focus-device]').forEach((button) => {
      button.addEventListener('click', () => {
        const card = button.closest('.device-card');
        const wasFocused = card.classList.contains('is-focused');
        document.querySelectorAll('.device-card').forEach((item) => item.classList.remove('is-focused'));
        board.classList.toggle('has-focus', !wasFocused);
        if (!wasFocused) card.classList.add('is-focused');
        button.textContent = wasFocused ? button.dataset.defaultLabel : '一覧に戻る';
      });
    });
  <\/script>
</body>
</html>`;
}

function demoStructuralFlowHtml({ input, consolidated = false, model: suppliedModel = null }) {
  const safeTitle = escapeMarkup(input.title);
  const safePrompt = escapeMarkup(input.prompt);
  const allowGoogleFonts = Boolean(input.settings?.allowGoogleFonts);
  const fontLinks = allowGoogleFonts
    ? '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Kalam:wght@400;700&family=Zen+Kurenaido&display=swap" rel="stylesheet">'
    : "";
  const initialModel = suppliedModel || demoFlowModel(input, "direction-a");
  const encodedModel = JSON.stringify(initialModel).replaceAll("<", "\\u003c");

  return `<!doctype html>
<html lang="ja">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${safeTitle} — 構造ワイヤー</title>
  ${fontLinks}
  <style>
    :root{font-family:"Hiragino Sans","Yu Gothic",system-ui,sans-serif;color:#232323;background:#f3f1ec;--ink:#292929;--muted:#74716c;--line:#bdb9b2;--paper:#fbfaf7;--accent:#315efb;--card-w:236px;--card-h:292px}
    *{box-sizing:border-box}body{margin:0;background-image:radial-gradient(rgba(40,40,40,.07) 1px,transparent 1px);background-size:22px 22px}button,input,select{font:inherit}button{cursor:pointer}
    .flow-app{min-height:100vh}.flow-header{position:sticky;top:0;z-index:30;display:flex;justify-content:space-between;gap:20px;align-items:center;padding:14px 18px;background:rgba(251,250,247,.95);border-bottom:1px solid #d7d3cc;backdrop-filter:blur(14px)}
    .flow-title p,.flow-title h1{margin:0}.flow-title p{color:var(--muted);font-size:9px;font-weight:700;letter-spacing:.1em}.flow-title h1{margin-top:4px;font-size:18px}
    .flow-toolbar,.view-tabs,.edit-actions{display:flex;gap:7px;align-items:center;flex-wrap:wrap}.tool-button,.view-tab{min-height:34px;padding:0 11px;background:#fff;border:1px solid #d2cec7;border-radius:9px;color:#55514c;font-size:10px;font-weight:600}.view-tab.is-active,.tool-button.is-active{color:#fff;background:var(--ink);border-color:var(--ink)}.tool-button:disabled,.view-tab:disabled{cursor:not-allowed;opacity:.42}
    .token-free{color:#557060;font-size:9px;font-weight:700}.save-state{min-width:84px;color:var(--muted);font-size:9px;text-align:right}
    .flow-intro{display:flex;justify-content:space-between;gap:20px;align-items:start;padding:18px 24px 0}.flow-intro p{max-width:820px;margin:0;color:#66625d;font-size:11px;line-height:1.65}.legend{display:flex;gap:14px;white-space:nowrap;color:#66625d;font-size:9px}.legend span::before{content:"";display:inline-block;width:24px;margin-right:6px;border-top:2px solid var(--ink);vertical-align:middle}.legend .dashed::before{border-top-style:dashed}
    .stage-shell{overflow:auto;padding:18px 24px 50px}.flow-canvas{position:relative;width:1450px;height:920px;min-height:600px}.flow-wires{position:absolute;z-index:2;inset:0;width:100%;height:100%;overflow:visible;pointer-events:none}.flow-edge{fill:none;stroke:var(--ink);stroke-width:2;stroke-linecap:round;stroke-linejoin:round;pointer-events:none}.flow-edge.is-dashed{stroke:#85817a;stroke-dasharray:7 6}.edge-label{position:absolute;z-index:6;transform:translate(-50%,-50%);padding:4px 8px;background:#f3f1ec;border:1px solid #d5d1ca;border-radius:7px;font-family:"Zen Kurenaido","Hiragino Sans",sans-serif;font-size:10px;white-space:nowrap;touch-action:none}.is-editing .edge-label{cursor:grab}.is-editing .edge-label:active{cursor:grabbing}
    .screen-card{position:absolute;z-index:4;width:var(--card-w);min-height:var(--card-h);padding:12px;background:#fff;border:2px solid var(--ink);border-radius:17px;box-shadow:4px 5px 0 rgba(37,37,37,.12)}.screen-card-header{display:flex;justify-content:space-between;gap:10px;align-items:start;padding-bottom:9px;border-bottom:1px dashed #bdb9b2}.screen-card-header p,.screen-card-header h2{margin:0}.screen-card-header p{color:#77736d;font:700 9px/1 "Kalam",cursive;letter-spacing:.06em}.screen-card-header h2{margin-top:5px;font-family:"Zen Kurenaido","Hiragino Sans",sans-serif;font-size:17px;line-height:1.2}
    .screen-card-body{display:grid;gap:9px;padding-top:11px;font-family:"Zen Kurenaido","Hiragino Sans",sans-serif}.screen-lead{min-height:35px;margin:0;font-size:12px;line-height:1.5}.wire-field,.wire-note,.wire-row,.wire-compare{padding:8px 9px;border:1.5px solid #77736d;border-radius:9px;font-size:10px}.wire-field{color:#77736d;border-style:dashed}.wire-note{line-height:1.5}.wire-row,.wire-compare{display:flex;justify-content:space-between;gap:8px}.wire-button{min-height:34px;color:#fff;background:var(--ink);border:0;border-radius:8px;font-size:10px;font-weight:600}.image-skeleton{display:grid;place-items:center;aspect-ratio:4/3;color:#8a8781;background:repeating-linear-gradient(135deg,#e8e6e1,#e8e6e1 9px,#f0eee9 9px,#f0eee9 18px);border:1.5px solid #9d9992;border-radius:9px;font-size:9px}
    .is-editing .screen-card-header{cursor:grab}.is-editing .screen-card-header:active{cursor:grabbing}.is-editing [data-editable]{outline:1px dashed transparent;outline-offset:3px}.is-editing [data-editable]:hover,.is-editing [data-editable]:focus{outline-color:var(--accent)}.is-editing .screen-card.is-selected{box-shadow:0 0 0 3px rgba(49,94,251,.2),4px 5px 0 rgba(37,37,37,.12)}
    .flow-app[data-view="list"] .flow-canvas{display:grid;grid-template-columns:repeat(auto-fill,minmax(236px,1fr));gap:22px;align-items:start;width:auto;height:auto}.flow-app[data-view="list"] .screen-card{position:relative!important;left:auto!important;top:auto!important;align-self:start;width:auto;height:max-content;min-height:292px}.flow-app[data-view="list"] .flow-wires,.flow-app[data-view="list"] .edge-label{display:none}
    @media(max-width:780px){.flow-header{align-items:flex-start;flex-direction:column}.flow-intro{flex-direction:column}.token-free,.save-state{display:none}}
  </style>
</head>
<body>
  <main class="flow-app" id="flow-app" data-view="flow">
    <header class="flow-header">
      <div class="flow-title"><p>${consolidated ? "FINAL STRUCTURAL WIREFRAME" : "STRUCTURAL WIREFRAME"}</p><h1 data-project-title>${safeTitle}</h1></div>
      <div class="flow-toolbar">
        <div class="view-tabs" role="tablist" aria-label="表示切り替え">
          <button class="view-tab is-active" type="button" data-view-button="flow">フローマップ</button>
          <button class="view-tab" type="button" data-view-button="list">画面一覧</button>
        </div>
        <span class="token-free">直接編集・トークン消費なし</span>
        <div class="edit-actions">
          <button class="tool-button" type="button" id="edit-toggle">直接編集</button>
          <button class="tool-button" type="button" id="auto-layout" disabled>自動整列</button>
          <button class="tool-button" type="button" id="undo" disabled aria-label="元に戻す">↶</button>
          <button class="tool-button" type="button" id="redo" disabled aria-label="やり直す">↷</button>
          <button class="tool-button" type="button" id="export-html">HTML保存</button>
        </div>
        <span class="save-state" id="save-state">編集できます</span>
      </div>
    </header>
    <section class="flow-intro">
      <p>${safePrompt}<br>画面カードは情報構造、画像枠、主要アクションを示します。編集モードでは、カード位置と文言、矢印ラベルの位置を調整できます。導線構造の変更はチャットで依頼してください。</p>
      <div class="legend"><span>実線</span><span class="dashed">破線</span></div>
    </section>
    <section class="stage-shell">
      <div class="flow-canvas" id="flow-canvas">
        <svg class="flow-wires" id="flow-wires" aria-hidden="true"><defs><marker id="arrow" markerWidth="9" markerHeight="9" refX="7" refY="4.5" orient="auto-start-reverse"><path d="M0,0 L9,4.5 L0,9 z" fill="#292929"></path></marker><marker id="arrow-back" markerWidth="9" markerHeight="9" refX="7" refY="4.5" orient="auto-start-reverse"><path d="M0,0 L9,4.5 L0,9 z" fill="#85817a"></path></marker></defs></svg>
      </div>
    </section>
  </main>
  <script id="flow-model" type="application/json">${encodedModel}<\/script>
  <script>
    (function(){
      var app=document.getElementById("flow-app");
      var canvas=document.getElementById("flow-canvas");
      var wires=document.getElementById("flow-wires");
      var modelElement=document.getElementById("flow-model");
      var model=JSON.parse(modelElement.textContent);
      var editing=false;
      var selectedScreenId=model.screens[0]&&model.screens[0].id;
      var history=[clone(model)];
      var historyIndex=0;
      var editStartState="";
      var saveTimer=0;
      var storageKey="ai-product-designer:flow:"+String(model.title||"design")+":"+String(model.directionId||"final");

      function clone(value){return JSON.parse(JSON.stringify(value))}
      function escapeText(value){return String(value).replace(/[&<>"']/g,function(char){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[char]})}
      function screenMarkup(screen){
        return '<article class="screen-card" data-screen-id="'+escapeText(screen.id)+'" data-x="'+screen.x+'" data-y="'+screen.y+'" style="left:'+screen.x+'px;top:'+screen.y+'px"><header class="screen-card-header"><div><p data-editable>'+escapeText(screen.eyebrow||"SCREEN")+'</p><h2 data-editable>'+escapeText(screen.title)+'</h2></div></header><div class="screen-card-body">'+screen.body+'</div></article>';
      }
      function renderScreens(){
        canvas.querySelectorAll(".screen-card,.edge-label").forEach(function(node){node.remove()});
        model.screens.forEach(function(screen){canvas.insertAdjacentHTML("beforeend",screenMarkup(screen))});
        bindCards();
        if(app.dataset.view==="flow")resolveAllOverlaps();
        syncModelFromDom();
        renderEdges();
      }
      function syncModelFromDom(){
        model.screens=Array.from(canvas.querySelectorAll(".screen-card")).map(function(card){
          return {id:card.dataset.screenId,x:Number(card.dataset.x),y:Number(card.dataset.y),title:card.querySelector("h2").textContent.trim()||"名称未設定",eyebrow:card.querySelector(".screen-card-header p").textContent.trim()||"SCREEN",body:card.querySelector(".screen-card-body").innerHTML};
        });
        model.title=document.querySelector("[data-project-title]").textContent.trim()||model.title;
      }
      function screenById(id){return model.screens.find(function(screen){return screen.id===id})}
      function cardMetrics(id){
        var card=canvas.querySelector('[data-screen-id="'+CSS.escape(id)+'"]');
        if(!card)return null;
        return {node:card,x:Number(card.dataset.x),y:Number(card.dataset.y),width:card.offsetWidth,height:card.offsetHeight};
      }
      function portOffset(edge, side){
        var siblings=model.edges.filter(function(item){
          return side==="out"?item.from===edge.from:item.to===edge.to;
        });
        var index=Math.max(0,siblings.findIndex(function(item){return item.id===edge.id}));
        return (index-(siblings.length-1)/2)*42;
      }
      function pointForSide(metric,side,offset){
        var value=Number(offset||0);
        if(side==="top"||side==="bottom"){
          var horizontal=Math.max(28,Math.min(metric.width-28,metric.width/2+value));
          return {x:metric.x+horizontal,y:side==="top"?metric.y:metric.y+metric.height};
        }
        var vertical=Math.max(28,Math.min(metric.height-28,metric.height/2+value));
        return {x:side==="left"?metric.x:metric.x+metric.width,y:metric.y+vertical};
      }
      function sideVector(side){
        if(side==="top")return {x:0,y:-1};
        if(side==="bottom")return {x:0,y:1};
        if(side==="left")return {x:-1,y:0};
        return {x:1,y:0};
      }
      function defaultSides(from,to){
        var deltaX=to.x+to.width/2-(from.x+from.width/2);
        var deltaY=to.y+to.height/2-(from.y+from.height/2);
        if(Math.abs(deltaX)>=Math.abs(deltaY))return deltaX>=0?{from:"right",to:"left"}:{from:"left",to:"right"};
        return deltaY>=0?{from:"bottom",to:"top"}:{from:"top",to:"bottom"};
      }
      function simplifyRoute(points){
        return points.filter(function(point,index){
          if(index===0||index===points.length-1)return true;
          var previous=points[index-1],next=points[index+1];
          return !((previous.x===point.x&&point.x===next.x)||(previous.y===point.y&&point.y===next.y));
        });
      }
      function segmentBlocked(first,second,obstacles){
        var epsilon=.5;
        if(first.y===second.y){
          var left=Math.min(first.x,second.x),right=Math.max(first.x,second.x);
          return obstacles.some(function(obstacle){
            return first.y>obstacle.top+epsilon&&first.y<obstacle.bottom-epsilon&&right>obstacle.left+epsilon&&left<obstacle.right-epsilon;
          });
        }
        var top=Math.min(first.y,second.y),bottom=Math.max(first.y,second.y);
        return obstacles.some(function(obstacle){
          return first.x>obstacle.left+epsilon&&first.x<obstacle.right-epsilon&&bottom>obstacle.top+epsilon&&top<obstacle.bottom-epsilon;
        });
      }
      function routeAroundCards(edge,from,to,fromSide,toSide){
        var start=pointForSide(from,fromSide,portOffset(edge,"out"));
        var end=pointForSide(to,toSide,portOffset(edge,"in"));
        var fromVector=sideVector(fromSide);
        var toVector=sideVector(toSide);
        var clearance=24;
        var stubGap=clearance+14;
        var startStub={x:start.x+fromVector.x*stubGap,y:start.y+fromVector.y*stubGap};
        var endStub={x:end.x+toVector.x*stubGap,y:end.y+toVector.y*stubGap};
        var obstacles=model.screens.map(function(screen){
          var metric=cardMetrics(screen.id);
          return metric?{left:metric.x-clearance,top:metric.y-clearance,right:metric.x+metric.width+clearance,bottom:metric.y+metric.height+clearance}:null;
        }).filter(Boolean);
        var xs=[startStub.x,endStub.x],ys=[startStub.y,endStub.y];
        obstacles.forEach(function(obstacle){xs.push(obstacle.left,obstacle.right);ys.push(obstacle.top,obstacle.bottom)});
        xs=Array.from(new Set(xs.map(function(value){return Math.round(value)}))).sort(function(a,b){return a-b});
        ys=Array.from(new Set(ys.map(function(value){return Math.round(value)}))).sort(function(a,b){return a-b});
        function pointBlocked(point){
          return obstacles.some(function(obstacle){return point.x>obstacle.left+.5&&point.x<obstacle.right-.5&&point.y>obstacle.top+.5&&point.y<obstacle.bottom-.5});
        }
        var nodes=[],nodeIndex={};
        ys.forEach(function(y){xs.forEach(function(x){
          var point={x:x,y:y};
          if(pointBlocked(point))return;
          nodeIndex[x+","+y]=nodes.length;
          nodes.push(point);
        })});
        function indexFor(point){return nodeIndex[Math.round(point.x)+","+Math.round(point.y)]}
        var startIndex=indexFor(startStub),endIndex=indexFor(endStub);
        if(startIndex===undefined||endIndex===undefined){
          var direct=[start,startStub,{x:startStub.x,y:endStub.y},endStub,end];
          return routeResult(simplifyRoute(direct),start,end);
        }
        var neighbors=nodes.map(function(){return []});
        ys.forEach(function(y){
          var row=xs.map(function(x){return nodeIndex[x+","+y]}).filter(function(index){return index!==undefined});
          row.forEach(function(index,position){
            var next=row[position+1];
            if(next===undefined||segmentBlocked(nodes[index],nodes[next],obstacles))return;
            var distance=Math.abs(nodes[next].x-nodes[index].x);
            neighbors[index].push({index:next,distance:distance,direction:"h"});
            neighbors[next].push({index:index,distance:distance,direction:"h"});
          });
        });
        xs.forEach(function(x){
          var column=ys.map(function(y){return nodeIndex[x+","+y]}).filter(function(index){return index!==undefined});
          column.forEach(function(index,position){
            var next=column[position+1];
            if(next===undefined||segmentBlocked(nodes[index],nodes[next],obstacles))return;
            var distance=Math.abs(nodes[next].y-nodes[index].y);
            neighbors[index].push({index:next,distance:distance,direction:"v"});
            neighbors[next].push({index:index,distance:distance,direction:"v"});
          });
        });
        var desiredX=(startStub.x+endStub.x)/2+Number(edge.routeOffsetX||0);
        var desiredY=(startStub.y+endStub.y)/2+Number(edge.routeOffsetY||0);
        var queue=[{index:startIndex,direction:"",cost:0,key:startIndex+"|"}];
        var costs={};costs[startIndex+"|"]=0;
        var previous={};
        var winner=null;
        while(queue.length){
          queue.sort(function(a,b){return a.cost-b.cost});
          var current=queue.shift();
          if(costs[current.key]!==current.cost)continue;
          if(current.index===endIndex){winner=current;break}
          neighbors[current.index].forEach(function(next){
            var bend=current.direction&&current.direction!==next.direction?34:0;
            var point=nodes[next.index];
            var bias=next.direction==="h"?Math.abs(point.y-desiredY)*.015:Math.abs(point.x-desiredX)*.015;
            var nextCost=current.cost+next.distance+bend+bias;
            var nextKey=next.index+"|"+next.direction;
            if(costs[nextKey]!==undefined&&costs[nextKey]<=nextCost)return;
            costs[nextKey]=nextCost;
            previous[nextKey]=current.key;
            queue.push({index:next.index,direction:next.direction,cost:nextCost,key:nextKey});
          });
        }
        if(!winner){
          var fallback=[start,startStub,{x:startStub.x,y:endStub.y},endStub,end];
          return routeResult(simplifyRoute(fallback),start,end);
        }
        var routed=[],routeKey=winner.key;
        while(routeKey){
          var routeIndex=Number(routeKey.split("|")[0]);
          routed.unshift(nodes[routeIndex]);
          routeKey=previous[routeKey];
        }
        routed.unshift(start);
        routed.push(end);
        return routeResult(simplifyRoute(routed),start,end);
      }
      function routeResult(points,start,end){
        var path=points.map(function(point,index){return (index?" L":"M")+point.x+","+point.y}).join("");
        var longest={length:-1,first:points[0],second:points[1]||points[0]};
        for(var index=0;index<points.length-1;index+=1){
          var first=points[index],second=points[index+1];
          var length=Math.abs(second.x-first.x)+Math.abs(second.y-first.y);
          if(length>longest.length)longest={length:length,first:first,second:second};
        }
        var horizontal=longest.first.y===longest.second.y;
        return {
          path:path,
          labelX:(longest.first.x+longest.second.x)/2+(horizontal?0:20),
          labelY:(longest.first.y+longest.second.y)/2+(horizontal?-18:0),
          axis:"both",
          start:start,
          end:end
        };
      }
      function routeManualEdge(edge,from,to){
        return routeAroundCards(edge,from,to,edge.fromSide,edge.toSide);
      }
      function ensureRoutingInsets(){
        var routingInset=96;
        var cards=Array.from(canvas.querySelectorAll(".screen-card"));
        if(!cards.length)return;
        var minX=Math.min.apply(null,cards.map(function(card){return Number(card.dataset.x)}));
        var minY=Math.min.apply(null,cards.map(function(card){return Number(card.dataset.y)}));
        var shiftX=Math.max(0,routingInset-minX);
        var shiftY=Math.max(0,routingInset-minY);
        if(!shiftX&&!shiftY)return;
        cards.forEach(function(card){
          var x=Number(card.dataset.x)+shiftX;
          var y=Number(card.dataset.y)+shiftY;
          card.dataset.x=x;
          card.dataset.y=y;
          card.style.left=x+"px";
          card.style.top=y+"px";
          var screen=screenById(card.dataset.screenId);
          if(screen){screen.x=x;screen.y=y}
        });
      }
      function renderEdges(){
        if(app.dataset.view!=="flow")return;
        canvas.querySelectorAll(".edge-label").forEach(function(node){node.remove()});
        wires.querySelectorAll(".flow-edge").forEach(function(node){node.remove()});
        ensureRoutingInsets();
        model.edges=model.edges.filter(function(edge){return screenById(edge.from)&&screenById(edge.to)});
        var metrics=model.screens.map(function(screen){return cardMetrics(screen.id)}).filter(Boolean);
        var maxRight=Math.max.apply(null,metrics.map(function(item){return item.x+item.width}).concat([1240]));
        var maxBottom=Math.max.apply(null,metrics.map(function(item){return item.y+item.height}).concat([760]));
        var routingMargin=210;
        canvas.style.width=Math.max(1450,maxRight+routingMargin)+"px";
        canvas.style.height=Math.max(920,maxBottom+routingMargin)+"px";
        model.edges.forEach(function(edge){
          var from=cardMetrics(edge.from);
          var to=cardMetrics(edge.to);
          if(!from||!to)return;
          var inferred=defaultSides(from,to);
          var routed=routeAroundCards(edge,from,to,edge.fromSide||inferred.from,edge.toSide||inferred.to);
          var pathData=routed.path;
          var labelX=routed.labelX;
          var labelY=routed.labelY;
          var path=document.createElementNS("http://www.w3.org/2000/svg","path");
          var lineStyle=edge.lineStyle||(edge.type==="back"?"dashed":"solid");
          path.setAttribute("class","flow-edge"+(lineStyle==="dashed"?" is-dashed":""));
          path.setAttribute("d",pathData);
          var marker=lineStyle==="dashed"?"url(#arrow-back)":"url(#arrow)";
          var arrowDirection=edge.arrowDirection||"forward";
          if(arrowDirection==="forward"||arrowDirection==="both")path.setAttribute("marker-end",marker);
          if(arrowDirection==="reverse"||arrowDirection==="both")path.setAttribute("marker-start",marker);
          wires.appendChild(path);
          var label=document.createElement("span");
          label.className="edge-label";
          label.dataset.edgeId=edge.id;
          label.textContent=edge.label;
          label.style.left=labelX+Number(edge.labelOffsetX||0)+"px";
          label.style.top=labelY+Number(edge.labelOffsetY||0)+"px";
          bindEdgeLabel(label,edge,labelX,labelY);
          canvas.appendChild(label);
        });
      }
      function bindEdgeLabel(label,edge,baseX,baseY){
        label.addEventListener("pointerdown",function(event){
          if(!editing||app.dataset.view!=="flow")return;
          event.preventDefault();
          event.stopPropagation();
          var startX=event.clientX,startY=event.clientY;
          var originX=Number(edge.labelOffsetX||0),originY=Number(edge.labelOffsetY||0);
          var moved=false;
          label.setPointerCapture(event.pointerId);
          function move(moveEvent){
            var deltaX=moveEvent.clientX-startX;
            var deltaY=moveEvent.clientY-startY;
            if(Math.abs(deltaX)+Math.abs(deltaY)>4)moved=true;
            if(!moved)return;
            edge.labelOffsetX=Math.round(originX+deltaX);
            edge.labelOffsetY=Math.round(originY+deltaY);
            label.style.left=baseX+edge.labelOffsetX+"px";
            label.style.top=baseY+edge.labelOffsetY+"px";
          }
          function end(){
            label.removeEventListener("pointermove",move);
            label.removeEventListener("pointerup",end);
            label.removeEventListener("pointercancel",cancel);
            if(!moved)return;
            commitModel();
          }
          function cancel(){
            label.removeEventListener("pointermove",move);
            label.removeEventListener("pointerup",end);
            label.removeEventListener("pointercancel",cancel);
          }
          label.addEventListener("pointermove",move);
          label.addEventListener("pointerup",end);
          label.addEventListener("pointercancel",cancel);
        });
      }
      function bindCards(){
        canvas.querySelectorAll(".screen-card").forEach(function(card){
          card.classList.toggle("is-selected",card.dataset.screenId===selectedScreenId);
          card.addEventListener("click",function(event){
            selectedScreenId=card.dataset.screenId;
            canvas.querySelectorAll(".screen-card").forEach(function(item){item.classList.toggle("is-selected",item===card)});
          });
          card.querySelectorAll("[data-editable]").forEach(function(node){
            node.contentEditable=editing?"true":"false";
            node.addEventListener("focus",function(){editStartState=JSON.stringify(captureModel())});
            node.addEventListener("blur",function(){if(editing&&editStartState!==JSON.stringify(captureModel()))commitFromDom()});
          });
          bindDrag(card);
        });
      }
      function bindDrag(card){
        var header=card.querySelector(".screen-card-header");
        header.addEventListener("pointerdown",function(event){
          if(!editing||app.dataset.view!=="flow"||event.target.closest("button")||event.target.closest("[contenteditable=true]"))return;
          event.preventDefault();
          var startX=event.clientX,startY=event.clientY,originX=Number(card.dataset.x),originY=Number(card.dataset.y);
          header.setPointerCapture(event.pointerId);
          function move(moveEvent){
            var x=Math.max(96,Math.round(originX+moveEvent.clientX-startX));
            var y=Math.max(96,Math.round(originY+moveEvent.clientY-startY));
            card.dataset.x=x;card.dataset.y=y;card.style.left=x+"px";card.style.top=y+"px";renderEdges();
          }
          function end(){
            header.removeEventListener("pointermove",move);
            header.removeEventListener("pointerup",end);
            preventOverlap(card);
            commitFromDom();
          }
          header.addEventListener("pointermove",move);
          header.addEventListener("pointerup",end);
        });
      }
      function overlaps(first,second,padding){
        var ax=Number(first.dataset.x),ay=Number(first.dataset.y),aw=first.offsetWidth,ah=first.offsetHeight;
        var bx=Number(second.dataset.x),by=Number(second.dataset.y),bw=second.offsetWidth,bh=second.offsetHeight;
        return ax<bx+bw+padding&&ax+aw+padding>bx&&ay<by+bh+padding&&ay+ah+padding>by;
      }
      function preventOverlap(card){
        var guard=0;
        while(guard<model.screens.length*3){
          var collision=Array.from(canvas.querySelectorAll(".screen-card")).find(function(other){return other!==card&&overlaps(card,other,28)});
          if(!collision)break;
          var nextY=Number(collision.dataset.y)+collision.offsetHeight+56;
          card.dataset.y=nextY;
          card.style.top=nextY+"px";
          guard+=1;
        }
      }
      function resolveAllOverlaps(){
        Array.from(canvas.querySelectorAll(".screen-card")).forEach(function(card){preventOverlap(card)});
      }
      function captureModel(){syncModelFromDom();return clone(model)}
      function commitFromDom(){syncModelFromDom();commitModel()}
      function commitModel(){
        modelElement.textContent=JSON.stringify(model);
        history=history.slice(0,historyIndex+1);
        history.push(clone(model));
        historyIndex=history.length-1;
        persist();
        updateHistoryButtons();
        renderEdges();
      }
      function applyModel(next){
        model=clone(next);
        modelElement.textContent=JSON.stringify(model);
        renderScreens();
        persist();
        updateHistoryButtons();
      }
      function persist(){
        window.clearTimeout(saveTimer);
        document.getElementById("save-state").textContent="保存中…";
        modelElement.textContent=JSON.stringify(model);
        try{window.parent.postMessage({type:"ai-product-designer:artifact-updated",html:"<!doctype html>\\n"+document.documentElement.outerHTML},"*")}catch(error){}
        saveTimer=window.setTimeout(function(){
          try{localStorage.setItem(storageKey,JSON.stringify(model))}catch(error){}
          document.getElementById("save-state").textContent="変更を反映済み";
        },180);
      }
      function updateHistoryButtons(){document.getElementById("undo").disabled=!editing||historyIndex<=0;document.getElementById("redo").disabled=!editing||historyIndex>=history.length-1}
      function setEditing(value){
        editing=value;app.classList.toggle("is-editing",editing);
        document.getElementById("edit-toggle").classList.toggle("is-active",editing);
        document.getElementById("edit-toggle").textContent=editing?"編集を終了":"直接編集";
        document.getElementById("auto-layout").disabled=!editing||app.dataset.view!=="flow";
        renderScreens();
        updateHistoryButtons();
      }
      function autoLayout(){
        syncModelFromDom();
        var forwardEdges=model.edges.filter(function(edge){return edge.type!=="back"});
        var incoming={};
        model.screens.forEach(function(screen){incoming[screen.id]=0});
        forwardEdges.forEach(function(edge){incoming[edge.to]=(incoming[edge.to]||0)+1});
        var roots=model.screens.filter(function(screen){return !incoming[screen.id]}).map(function(screen){return screen.id});
        if(!roots.length&&model.screens[0])roots=[model.screens[0].id];
        var levelById={},queue=roots.map(function(id){return {id:id,level:0}});
        while(queue.length){
          var current=queue.shift();
          if(levelById[current.id]!==undefined)continue;
          levelById[current.id]=current.level;
          forwardEdges.filter(function(edge){return edge.from===current.id}).forEach(function(edge){queue.push({id:edge.to,level:current.level+1})});
        }
        model.screens.forEach(function(screen){if(levelById[screen.id]===undefined)levelById[screen.id]=0});
        var groups={};
        model.screens.forEach(function(screen){var level=levelById[screen.id];(groups[level]||(groups[level]=[])).push(screen)});
        Object.keys(groups).forEach(function(levelKey){
          var items=groups[levelKey];
          var level=Number(levelKey);
          var gap=70;
          var heights=items.map(function(screen){var metric=cardMetrics(screen.id);return metric?metric.height:310});
          var total=heights.reduce(function(sum,height){return sum+height},0)+gap*Math.max(0,items.length-1);
          var y=Math.max(96,(980-total)/2);
          items.forEach(function(screen,index){screen.x=110+level*360;screen.y=Math.round(y);y+=heights[index]+gap});
        });
        renderScreens();
        commitModel();
      }
      function exportHtml(){
        syncModelFromDom();modelElement.textContent=JSON.stringify(model);
        var html="<!doctype html>\\n"+document.documentElement.outerHTML;
        var url=URL.createObjectURL(new Blob([html],{type:"text/html;charset=utf-8"}));
        var anchor=document.createElement("a");anchor.href=url;anchor.download=(model.title||"structural-wireframe").replace(/[^a-zA-Z0-9ぁ-んァ-ヶ一-龠_-]+/g,"-")+"-flow.html";document.body.appendChild(anchor);anchor.click();anchor.remove();URL.revokeObjectURL(url);
      }
      document.querySelectorAll("[data-view-button]").forEach(function(button){button.addEventListener("click",function(){
        if(button.disabled)return;
        app.dataset.view=button.dataset.viewButton;
        document.querySelectorAll("[data-view-button]").forEach(function(item){item.classList.toggle("is-active",item===button)});
        document.getElementById("auto-layout").disabled=!editing||button.dataset.viewButton!=="flow";
        if(button.dataset.viewButton==="flow")window.requestAnimationFrame(function(){renderEdges()});
      })});
      document.getElementById("edit-toggle").addEventListener("click",function(){setEditing(!editing)});
      document.getElementById("auto-layout").addEventListener("click",autoLayout);
      document.getElementById("undo").addEventListener("click",function(){if(historyIndex>0){historyIndex-=1;applyModel(history[historyIndex])}});
      document.getElementById("redo").addEventListener("click",function(){if(historyIndex<history.length-1){historyIndex+=1;applyModel(history[historyIndex])}});
      document.getElementById("export-html").addEventListener("click",exportHtml);
      window.addEventListener("resize",renderEdges);
      renderScreens();updateHistoryButtons();
    })();
  <\/script>
</body>
</html>`;
}

window.AIProductDesignerArtifactRenderer = Object.freeze({
  structuralFlowHtml: demoStructuralFlowHtml,
});

function demoFlowPrototypeScreenHtml({ input, viewport, model, presentationPhase = "wireframe" }) {
  const safeTitle = escapeMarkup(input.title);
  const wireframeVisuals = presentationPhase === "wireframe";
  const accent = wireframeVisuals ? "#252525" : "#315efb";
  const surface = wireframeVisuals ? "#ffffff" : "#f7f8fb";
  const border = wireframeVisuals ? "#252525" : "#dce1eb";
  const shadow = wireframeVisuals ? "5px 6px 0 rgba(37,37,37,.10)" : "0 18px 46px rgba(35,53,91,.10)";
  const screens = model.screens
    .map(
      (screen, index) => `
        <section class="proto-screen" data-screen-id="${escapeAttribute(screen.id)}" ${index ? "hidden" : ""}>
          <header class="screen-card-header">
            <p>${escapeMarkup(screen.eyebrow || `SCREEN ${index + 1}`)}</p>
            <h1>${escapeMarkup(screen.title)}</h1>
          </header>
          <div class="screen-card-body">${screen.body || ""}</div>
        </section>
      `,
    )
    .join("");
  const flowData = JSON.stringify({
    start: model.screens[0]?.id,
    edges: Array.isArray(model.edges) ? model.edges : [],
  }).replaceAll("<", "\\u003c");
  const fontImport = wireframeVisuals && input.settings?.allowGoogleFonts
    ? '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Zen+Kurenaido&display=swap" rel="stylesheet">'
    : "";
  const fontFamily = wireframeVisuals
    ? '"Zen Kurenaido","Hiragino Sans","Yu Gothic",system-ui,sans-serif'
    : '"Hiragino Sans","Yu Gothic",system-ui,sans-serif';

  return `<!doctype html>
<html lang="ja">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${safeTitle} — ${escapeMarkup(viewport.label)} prototype</title>
  ${fontImport}
  <style>
    :root{font-family:${fontFamily};color:#252525;background:${surface}}
    *{box-sizing:border-box}body{min-height:100vh;margin:0;background:${surface}}button{font:inherit}
    .prototype-stage{display:grid;place-items:start center;min-height:100vh;padding:clamp(18px,4vw,48px)}
    .proto-screen{width:min(100%,720px);padding:clamp(20px,4vw,38px);background:#fff;border:${wireframeVisuals ? "2px" : "1px"} solid ${border};border-radius:24px;box-shadow:${shadow}}
    .screen-card-header{padding-bottom:16px;border-bottom:1px dashed #aaa6a0}.screen-card-header p{margin:0 0 5px;color:#6f6b65;font-size:11px;letter-spacing:.06em}.screen-card-header h1{margin:0;font-size:clamp(25px,5vw,42px);font-weight:400;line-height:1.25}
    .screen-card-body{display:grid;gap:12px;padding-top:20px}.screen-lead{margin:0 0 3px;font-size:clamp(15px,2.5vw,21px);line-height:1.55}
    .wire-field,.wire-note,.wire-row,.wire-compare{padding:12px 14px;background:${wireframeVisuals ? "#fff" : "#f7f8fb"};border:1.5px solid ${wireframeVisuals ? "#77736d" : "#d8deea"};border-radius:11px;font-size:14px}.wire-field{color:#77736d;${wireframeVisuals ? "border-style:dashed" : ""}}.wire-note{line-height:1.55}.wire-row,.wire-compare{display:flex;justify-content:space-between;gap:10px}
    .wire-button{min-height:46px;padding:0 16px;color:#fff;background:${accent};border:0;border-radius:10px;font-size:14px;font-weight:${wireframeVisuals ? "400" : "500"};cursor:pointer}.wire-button:focus-visible{outline:3px solid #315efb;outline-offset:3px}.wire-button:disabled{color:#8b8882;background:#e5e3df;cursor:not-allowed}
    .image-skeleton{display:grid;place-items:center;aspect-ratio:4/3;color:#7d7972;background:repeating-linear-gradient(135deg,#e8e6e1,#e8e6e1 10px,#f2f0eb 10px,#f2f0eb 20px);border:1.5px solid #9d9992;border-radius:12px;font-size:12px}
    .prototype-hotspot{position:relative;cursor:pointer;transition:box-shadow .15s ease,transform .15s ease}.prototype-hotspot:hover{box-shadow:0 0 0 3px rgba(49,94,251,.22);transform:translateY(-1px)}.prototype-hotspot:focus-visible{outline:3px solid #315efb;outline-offset:3px}.prototype-hotspot::after{content:"→";margin-left:auto;color:${accent};font-weight:700}
    .sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}
    [hidden]{display:none!important}
    @media(max-width:620px){.prototype-stage{padding:14px}.proto-screen{padding:20px;border-radius:18px}.screen-card-header h1{font-size:29px}.screen-card-body{gap:10px}.wire-field,.wire-note,.wire-row,.wire-compare{font-size:12px}}
  </style>
</head>
<body>
  <main class="prototype-stage" aria-label="${safeTitle}の操作プロトタイプ">
    ${screens}
    <p class="sr-only" id="prototype-status" aria-live="polite"></p>
  </main>
  <script>
    const flow = ${flowData};
    const screens = [...document.querySelectorAll('[data-screen-id]')];
    const status = document.querySelector('#prototype-status');
    function showScreen(id, transitionLabel) {
      const target = screens.find((screen) => screen.dataset.screenId === id);
      if (!target) return;
      screens.forEach((screen) => { screen.hidden = screen !== target; });
      status.textContent = transitionLabel ? transitionLabel + '。' + target.querySelector('h1').textContent + 'を表示しました。' : target.querySelector('h1').textContent + 'を表示しました。';
      target.querySelector('button:not(:disabled)')?.focus();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
    screens.forEach((screen) => {
      const outgoing = flow.edges.filter((edge) => edge.from === screen.dataset.screenId);
      const buttons = [...screen.querySelectorAll('button')];
      const choiceTargets = [...screen.querySelectorAll('.wire-row,.wire-compare')];
      const fallbackTargets = [...screen.querySelectorAll('.wire-note,.wire-field,.image-skeleton')];
      const triggers = [
        ...buttons,
        ...choiceTargets.filter((target) => !target.closest('button')),
        ...fallbackTargets.filter((target) => !target.closest('button')),
      ];
      outgoing.forEach((edge, index) => {
        const trigger = triggers[index];
        if (!trigger) return;
        trigger.dataset.prototypeBound = 'true';
        trigger.dataset.transitionLabel = edge.label || '次へ';
        trigger.classList.add('prototype-hotspot');
        if (trigger.tagName !== 'BUTTON') {
          trigger.setAttribute('role', 'button');
          trigger.tabIndex = 0;
        }
        const activate = () => showScreen(edge.to, edge.label);
        trigger.addEventListener('click', activate);
        trigger.addEventListener('keydown', (event) => {
          if (event.key !== 'Enter' && event.key !== ' ') return;
          event.preventDefault();
          activate();
        });
      });
      buttons.filter((button) => button.dataset.prototypeBound !== 'true').forEach((button) => {
        if (!outgoing.length) {
          button.addEventListener('click', () => {
            button.textContent = '完了しました';
            button.disabled = true;
            status.textContent = screen.querySelector('h1').textContent + 'の操作が完了しました。';
          });
        } else {
          button.disabled = true;
        }
      });
    });
  <\/script>
</body>
</html>`;
}

function demoScreenHtml({
  phase,
  input,
  viewport,
  consolidated,
  prototypeBasePhase = null,
  sourceFlowModel = null,
}) {
  if (
    phase === "prototype" &&
    Array.isArray(sourceFlowModel?.screens) &&
    sourceFlowModel.screens.length
  ) {
    return demoFlowPrototypeScreenHtml({
      input,
      viewport,
      model: sourceFlowModel,
      presentationPhase: prototypeBasePhase || "wireframe",
    });
  }
  const safeTitle = escapeMarkup(input.title);
  const safePrompt = escapeMarkup(input.prompt);
  const isWireframe = phase === "wireframe";
  const isStructural = isWireframe && input.outputLevel === "structural-wireframe";
  const isPrototype = phase === "prototype";
  const keepsWireframeVisuals = isWireframe || (isPrototype && prototypeBasePhase === "wireframe");
  const accent = keepsWireframeVisuals ? "#252525" : "#315efb";
  const cardShadow = keepsWireframeVisuals ? "none" : "0 12px 30px rgba(36,58,130,.10)";
  const useZenKurenaido =
    (isStructural || (isPrototype && prototypeBasePhase === "wireframe" && input.outputLevel === "structural-wireframe")) &&
    input.settings?.allowGoogleFonts;
  const fontImport = useZenKurenaido
    ? '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Zen+Kurenaido&display=swap" rel="stylesheet">'
    : "";
  const fontFamily = useZenKurenaido
    ? '"Zen Kurenaido","Hiragino Sans","Yu Gothic",system-ui,sans-serif'
    : '"Hiragino Sans","Yu Gothic",system-ui,sans-serif';
  const canvasBackground = keepsWireframeVisuals ? "#ffffff" : "#f4f3ef";
  const controlWeight = keepsWireframeVisuals ? 400 : 500;
  const artifactLabel = isWireframe
    ? consolidated
      ? "FINAL WIREFRAME"
      : "WIREFRAME OPTION"
    : isPrototype
      ? "INTERACTIVE PROTOTYPE"
      : "UI MOCKUP";
  const prototypeScript = isPrototype
    ? `<script>
        const savedCandidates = new Set();
        const listView = document.querySelector('#prototype-list');
        const detailView = document.querySelector('#prototype-detail');
        const detailTitle = document.querySelector('#detail-title');
        const detailMeta = document.querySelector('#detail-meta');
        const detailReason = document.querySelector('#detail-reason');
        const saveButton = document.querySelector('#save-candidate');
        const emptySaved = document.querySelector('#saved-empty');
        let activeMode = 'recommend';

        function renderCandidateMode() {
          let visibleCount = 0;
          document.querySelectorAll('[data-candidate]').forEach((card) => {
            const visible = activeMode !== 'saved' || savedCandidates.has(card.dataset.candidate);
            card.hidden = !visible;
            if (visible) visibleCount += 1;
          });
          emptySaved.hidden = activeMode !== 'saved' || visibleCount > 0;
          document.querySelector('#demo-state').textContent =
            activeMode === 'saved'
              ? visibleCount
                ? '保存済みの候補を比較できます'
                : '保存した候補はまだありません'
              : '条件に合う候補を比較できます';
        }

        document.querySelectorAll('[data-tab]').forEach((button) => {
          button.addEventListener('click', () => {
            document.querySelectorAll('[data-tab]').forEach((item) => item.classList.remove('active'));
            button.classList.add('active');
            activeMode = button.dataset.tab;
            listView.hidden = false;
            detailView.hidden = true;
            renderCandidateMode();
          });
        });
        document.querySelectorAll('[data-open-candidate]').forEach((button) => {
          button.addEventListener('click', () => {
            detailTitle.textContent = button.dataset.name;
            detailMeta.textContent = button.dataset.meta;
            detailReason.textContent = button.dataset.reason;
            saveButton.dataset.name = button.dataset.name;
            saveButton.setAttribute('aria-pressed', String(savedCandidates.has(button.dataset.name)));
            saveButton.textContent = savedCandidates.has(button.dataset.name) ? '保存を解除' : '候補を保存';
            listView.hidden = true;
            detailView.hidden = false;
            detailView.focus();
          });
        });
        document.querySelector('#back-to-candidates').addEventListener('click', () => {
          detailView.hidden = true;
          listView.hidden = false;
          renderCandidateMode();
        });
        saveButton.addEventListener('click', () => {
          const name = saveButton.dataset.name;
          if (savedCandidates.has(name)) savedCandidates.delete(name);
          else savedCandidates.add(name);
          const isSaved = savedCandidates.has(name);
          saveButton.setAttribute('aria-pressed', String(isSaved));
          saveButton.textContent = isSaved ? '保存を解除' : '候補を保存';
        });
      <\/script>`
    : "";

  return `<!doctype html>
<html lang="ja">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${safeTitle} — ${viewport.label}</title>
  ${fontImport}
  <style>
    :root{font-family:${fontFamily};color:#202020;background:${canvasBackground}}
    *{box-sizing:border-box}body{margin:0}button{font:inherit}.page{width:min(1120px,calc(100% - 32px));margin:auto;padding:32px 0 70px}
    header{padding:0 2px 24px;border-bottom:1px solid #cfcfcf}.eyebrow{margin:0 0 8px;color:${accent};font-size:11px;font-weight:700;letter-spacing:.08em}
    h1{max-width:760px;margin:0;font-size:clamp(26px,4vw,48px);line-height:1.15}header p{max-width:560px;margin:12px 0 0;color:#6d6d6d;font-size:13px;line-height:1.7}
    nav{display:flex;gap:8px;margin:22px 0;${isPrototype ? `position:sticky;top:0;z-index:10;padding:12px 0;background:${canvasBackground}` : ""}}.tab{padding:10px 14px;border:1px solid #c9c9c9;border-radius:99px;background:#fff;font-weight:${controlWeight}}.tab.active{color:#fff;background:${accent};border-color:${accent}}
    .summary{display:grid;grid-template-columns:1.2fr .8fr;gap:16px;margin-top:${isPrototype ? "0" : "22px"}}.panel,.card{background:#fff;border:1px solid #cfcfcf;border-radius:18px;box-shadow:${cardShadow}}
    .panel{padding:22px}.panel h2{margin:0 0 8px;font-size:19px}.panel p{margin:0;color:#686868;font-size:12px;line-height:1.7}
    .filters{display:flex;flex-wrap:wrap;gap:8px;margin-top:18px}.chip{padding:8px 11px;border:1px solid #bdbdbd;border-radius:99px;font-size:11px}
    .cards{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-top:16px}.card{overflow:hidden}
    .media{aspect-ratio:4/3;display:grid;place-items:center;color:#8a8a8a;background:repeating-linear-gradient(135deg,#e6e6e6,#e6e6e6 10px,#ededed 10px,#ededed 20px);font-size:10px}
    .card-body{padding:16px}.card h3{margin:0;font-size:15px}.meta{display:flex;justify-content:space-between;gap:8px;margin:8px 0 13px;color:#757575;font-size:10px}
    .reason{padding:10px;background:#efefed;border-radius:10px;font-size:11px;line-height:1.55}.action{width:100%;margin-top:14px;padding:11px;color:#fff;background:${accent};border:0;border-radius:10px;font-weight:${controlWeight};letter-spacing:.01em}
    .decision{display:grid;gap:10px}.decision div{padding:12px;border:1px solid #d4d4d4;border-radius:12px}.decision strong,.decision small{display:block}.decision small{margin-top:5px;color:#777}
    [hidden]{display:none!important}.empty-state{margin:16px 0;padding:22px;color:#686868;background:#fff;border:1px dashed #aaa;border-radius:14px;text-align:center;font-size:12px}
    .detail-view{padding:22px;background:#fff;border:1px solid #cfcfcf;border-radius:18px}.detail-back{padding:0;color:#686868;background:transparent;border:0;font-size:11px}.detail-view h2{margin:24px 0 8px;font-size:24px}.detail-view>p{color:#686868;font-size:12px;line-height:1.7}.detail-actions{display:flex;gap:10px;margin-top:22px}.detail-actions button{min-height:42px;padding:0 16px;border-radius:10px}.detail-actions .action{width:auto;margin:0;border:1px solid ${accent}}
    footer{margin-top:18px;padding:15px;color:#686868;border:1px dashed #aaa;border-radius:12px;font-size:11px}
    @media(max-width:900px){.page{width:min(100% - 28px,760px);padding-top:24px}.summary{grid-template-columns:1fr}.cards{grid-template-columns:repeat(2,1fr)}}
    @media(max-width:620px){.page{width:calc(100% - 24px);padding:20px 0 40px}header{padding-bottom:18px}h1{font-size:30px}header p{font-size:12px}.summary,.cards{grid-template-columns:1fr}.cards{gap:11px}.panel{padding:17px}.card{display:grid;grid-template-columns:116px 1fr}.media{height:100%;min-height:178px;aspect-ratio:auto}.card-body{padding:13px}.reason{font-size:10px}}
  </style>
</head>
<body>
  <main class="page">
    <header><p class="eyebrow">${artifactLabel} · ${viewport.label.toUpperCase()}</p><h1>${safeTitle}</h1><p>${safePrompt}</p></header>
    ${isPrototype ? `<nav aria-label="表示切り替え"><button class="tab active" data-tab="recommend">おすすめ</button><button class="tab" data-tab="saved">保存済み</button></nav>` : ""}
    <div id="prototype-list">
      <section class="summary">
        <div class="panel"><h2 id="demo-state">条件に合う候補を比較できます</h2><p>希望条件との一致理由を先に示し、候補を開く前に違いを判断できる構成です。</p><div class="filters"><span class="chip">日付 8/22</span><span class="chip">大人2・子ども1</span><span class="chip">予算 15,000円</span></div></div>
        <div class="panel decision"><div><strong>比較の軸</strong><small>価格・移動・家族の希望</small></div><div><strong>候補数</strong><small>条件に合う3件</small></div></div>
      </section>
      <section class="cards" aria-label="候補一覧">
      ${["みなとエリア", "駅前エリア", "公園エリア"].map((name, index) => `
        <article class="card" data-candidate="${name}の候補">
          <div class="media" data-media-placeholder data-aspect-ratio="4:3">画像 ${index + 1}・4:3</div>
          <div class="card-body"><h3>${name}の候補</h3><div class="meta"><span>徒歩 ${8 + index * 3}分</span><strong>¥${(7800 + index * 1800).toLocaleString()}</strong></div><div class="reason">希望に合う理由：${index === 0 ? "移動が短く、子ども向け設備があります" : index === 1 ? "価格を抑えながら食事を選べます" : "混雑が少なく、屋外で過ごせます"}</div><button class="action"${isPrototype ? ` data-open-candidate data-name="${name}の候補" data-meta="徒歩 ${8 + index * 3}分・¥${(7800 + index * 1800).toLocaleString()}" data-reason="${index === 0 ? "移動が短く、子ども向け設備があります" : index === 1 ? "価格を抑えながら食事を選べます" : "混雑が少なく、屋外で過ごせます"}"` : ""}>${isPrototype ? "この候補を見る" : "詳細を確認"}</button></div>
        </article>`).join("")}
      </section>
      ${isPrototype ? '<p class="empty-state" id="saved-empty" hidden>保存した候補はまだありません。おすすめから候補を開いて保存してください。</p>' : ""}
    </div>
    ${isPrototype ? '<section class="detail-view" id="prototype-detail" tabindex="-1" hidden><button class="detail-back" id="back-to-candidates" type="button">← 候補一覧へ戻る</button><h2 id="detail-title"></h2><p id="detail-meta"></p><p id="detail-reason"></p><div class="detail-actions"><button class="action" id="save-candidate" type="button" aria-pressed="false">候補を保存</button></div></section>' : ""}
    <footer>${viewport.label} ${viewport.width}×${viewport.height}で確認するサンプル成果物です。</footer>
  </main>
  ${prototypeScript}
</body>
</html>`;
}

function escapeAttribute(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll('"', "&quot;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");
}

function escapeMarkup(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

window.AIProductDesignerDemoFlowModel = demoFlowModel;
