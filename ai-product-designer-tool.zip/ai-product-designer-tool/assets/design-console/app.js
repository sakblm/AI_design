const adapter = window.AIProductDesignerAdapter;
const draftStorageKey = "ai-product-designer:draft:v1";

const state = {
  session: null,
  artifact: null,
  artifactsByPhase: {},
  currentPhase: "wireframe",
  selectedDirectionId: null,
  evidenceFiles: [],
  designSystemFiles: [],
  evidenceBatchId: crypto.randomUUID(),
  isBusy: false,
  tokenTotal: 0,
};

const outputLevelLabels = {
  "structural-wireframe": "構造ワイヤー",
  "detailed-wireframe": "詳細ワイヤー",
  "ui-mockup": "UIモックアップ",
};

const phaseLabels = {
  wireframe: "ワイヤー",
  "ui-mockup": "UIモックアップ",
  prototype: "プロトタイプ",
};

const elements = {
  appShell: document.querySelector("#app-shell"),
  intakeView: document.querySelector("#intake-view"),
  workspaceView: document.querySelector("#workspace-view"),
  requestForm: document.querySelector("#request-form"),
  chatForm: document.querySelector("#chat-form"),
  chatInput: document.querySelector("#chat-input"),
  chatMessages: document.querySelector("#chat-messages"),
  chatContext: document.querySelector("#chat-context"),
  chatPhase: document.querySelector("#chat-phase"),
  chatProjectTitle: document.querySelector("#chat-project-title"),
  evidenceDropzone: document.querySelector("#evidence-dropzone"),
  evidenceFiles: document.querySelector("#evidence-files"),
  evidenceFolder: document.querySelector("#evidence-folder"),
  evidenceFileList: document.querySelector("#evidence-file-list"),
  designSystemDropzone: document.querySelector("#design-system-dropzone"),
  designSystemFiles: document.querySelector("#design-system-files"),
  designSystemFolder: document.querySelector("#design-system-folder"),
  designSystemFileList: document.querySelector("#design-system-file-list"),
  workspaceTitle: document.querySelector("#workspace-title"),
  artifactStatus: document.querySelector("#artifact-status"),
  artifactLabel: document.querySelector("#artifact-label"),
  previewLoading: document.querySelector("#preview-loading"),
  artifactPreview: document.querySelector("#artifact-preview"),
  phaseActions: document.querySelector("#phase-actions"),
  directionSelector: document.querySelector("#direction-selector"),
  phaseActionTitle: document.querySelector("#phase-action-title"),
  phaseActionNote: document.querySelector("#phase-action-note"),
  consolidateDirection: document.querySelector("#consolidate-direction"),
  phaseActionButtons: document.querySelector(".phase-action-buttons"),
  tokenTotal: document.querySelector("#token-total"),
  tokenModeLabel: document.querySelector("#token-mode-label"),
  openPreview: document.querySelector("#open-preview"),
  downloadArtifact: document.querySelector("#download-artifact"),
  saveDraft: document.querySelector("#save-draft"),
  restoreDraft: document.querySelector("#restore-draft"),
  toast: document.querySelector(".toast"),
};

let toastTimer;

bootstrap();

function bootstrap() {
  const connected = adapter?.mode === "connected";
  if (adapter?.mode === "local") elements.tokenModeLabel.textContent = "（ローカル・消費なし）";
  elements.tokenModeLabel.hidden = connected;
  elements.chatInput.disabled = false;
  elements.chatForm.querySelector("button").disabled = false;
  renderTokenUsage();
  bindEvents();
  renderAttachmentFiles("design-system");
  renderAttachmentFiles("reference");
  updateDraftControls();
}

function bindEvents() {
  for (const button of document.querySelectorAll("[data-chat-toggle]")) {
    button.addEventListener("click", toggleChat);
  }

  bindAttachmentIntake({
    kind: "design-system",
    dropzone: elements.designSystemDropzone,
    fileInput: elements.designSystemFiles,
    folderInput: elements.designSystemFolder,
    fileList: elements.designSystemFileList,
    chooseFiles: document.querySelector("#choose-design-system-files"),
    chooseFolder: document.querySelector("#choose-design-system-folder"),
  });
  bindAttachmentIntake({
    kind: "reference",
    dropzone: elements.evidenceDropzone,
    fileInput: elements.evidenceFiles,
    folderInput: elements.evidenceFolder,
    fileList: elements.evidenceFileList,
    chooseFiles: document.querySelector("#choose-files"),
    chooseFolder: document.querySelector("#choose-folder"),
  });

  elements.requestForm.addEventListener("submit", startCreation);
  elements.chatForm.addEventListener("submit", sendChatMessage);
  elements.chatInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      elements.chatForm.requestSubmit();
    }
  });

  document.querySelector("#back-to-intake").addEventListener("click", () => {
    if (state.session && !window.confirm("現在の制作セッションを閉じて、新しい制作を始めますか？")) return;
    resetSession();
  });
  for (const button of document.querySelectorAll("[data-next-phase]")) {
    button.addEventListener("click", () => advancePhase(button.dataset.nextPhase));
  }
  for (const button of document.querySelectorAll("[data-phase-target]")) {
    button.addEventListener("click", () => restorePhase(button.dataset.phaseTarget));
  }
  elements.consolidateDirection.addEventListener("click", consolidateDirection);
  elements.openPreview.addEventListener("click", openArtifact);
  elements.downloadArtifact.addEventListener("click", downloadArtifact);
  elements.saveDraft.addEventListener("click", saveDraft);
  elements.restoreDraft.addEventListener("click", restoreDraft);
  window.addEventListener("message", receiveArtifactEdit);
}

function bindAttachmentIntake({ kind, dropzone, fileInput, folderInput, fileList, chooseFiles, chooseFolder }) {
  chooseFiles.addEventListener("click", (event) => {
    event.stopPropagation();
    fileInput.click();
  });
  chooseFolder.addEventListener("click", (event) => {
    event.stopPropagation();
    folderInput.click();
  });

  for (const eventName of ["dragenter", "dragover"]) {
    dropzone.addEventListener(eventName, (event) => {
      event.preventDefault();
      dropzone.classList.add("is-dragging");
    });
  }
  for (const eventName of ["dragleave", "drop"]) {
    dropzone.addEventListener(eventName, (event) => {
      event.preventDefault();
      dropzone.classList.remove("is-dragging");
    });
  }
  dropzone.addEventListener("drop", async (event) => {
    try {
      addAttachmentFiles(kind, await filesFromDataTransfer(event.dataTransfer));
    } catch (error) {
      showToast(`資料を読み込めませんでした: ${error.message}`, true);
    }
  });
  fileInput.addEventListener("change", () => {
    addAttachmentFiles(kind, [...fileInput.files].map((file) => ({ file, relativePath: file.name })));
    fileInput.value = "";
  });
  folderInput.addEventListener("change", () => {
    addAttachmentFiles(
      kind,
      [...folderInput.files].map((file) => ({
        file,
        relativePath: file.webkitRelativePath || file.name,
      })),
    );
    folderInput.value = "";
  });
  fileList.addEventListener("click", (event) => {
    const button = event.target.closest("[data-remove-attachment]");
    if (!button) return;
    setAttachmentFiles(
      kind,
      attachmentFiles(kind).filter((item) => item.key !== button.dataset.removeAttachment),
    );
    renderAttachmentFiles(kind);
  });
}

async function startCreation(event) {
  event.preventDefault();
  if (state.isBusy) return;

  const promptField = document.querySelector("#prompt");
  let prompt = promptField.value.trim();
  const outputLevel = document.querySelector('[name="outputLevel"]:checked')?.value;
  const viewports = [...document.querySelectorAll('[name="viewport"]:checked')].map((item) => item.value);
  if (!prompt) return showToast("依頼内容を入力してください。", true);
  if (!viewports.length) return showToast("対象画面サイズを1つ以上選択してください。", true);

  const title = document.querySelector("#title").value.trim() || makeTitle(prompt);
  const createButton = elements.requestForm.querySelector(".create-button");
  const originalText = createButton.innerHTML;
  state.isBusy = true;
  createButton.disabled = true;

  try {
    const attachmentCount = state.designSystemFiles.length + state.evidenceFiles.length;
    createButton.textContent = attachmentCount ? "資料を準備しています…" : "制作を準備しています…";
    const uploadedAttachments = await uploadAttachmentFiles();
    const input = {
      title,
      prompt,
      outputLevel,
      settings: {
        compareDirections: Number(document.querySelector("#compare-directions").value),
        viewports,
        interactive: false,
        allowGoogleFonts: true,
      },
      designSystem: uploadedAttachments.designSystem,
      evidence: uploadedAttachments.reference,
      attachmentSummary: [
        ...state.designSystemFiles.map((item) => attachmentSummary(item, "design-system")),
        ...state.evidenceFiles.map((item) => attachmentSummary(item, "reference")),
      ],
    };

    state.session = await adapter.createSession(input);
    applyUsage(state.session?.usage);
    updateDraftControls();
    state.currentPhase = outputLevel === "ui-mockup" ? "ui-mockup" : "wireframe";
    showWorkspace(title, outputLevel);
    const designSystemSummary = state.designSystemFiles.length ? `${state.designSystemFiles.length}件` : "なし";
    const referenceSummary = state.evidenceFiles.length ? `${state.evidenceFiles.length}件` : "なし";
    appendMessage("agent", `「${title}」の制作を開始します。デザインシステム ${designSystemSummary}、参考資料 ${referenceSummary}で、${outputLevelLabels[outputLevel]}を準備します。`);
    await generateArtifact({ input, phase: state.currentPhase });
  } catch (error) {
    showToast(error.message || "制作を開始できませんでした。", true);
    setArtifactStatus("error", "準備に失敗しました");
  } finally {
    state.isBusy = false;
    createButton.disabled = false;
    createButton.innerHTML = originalText;
  }
}

function showWorkspace(title, outputLevel) {
  elements.intakeView.hidden = true;
  elements.workspaceView.hidden = false;
  elements.workspaceTitle.textContent = title;
  elements.chatContext.hidden = false;
  elements.chatProjectTitle.textContent = title;
  elements.chatPhase.textContent = outputLevelLabels[outputLevel] || phaseLabels[state.currentPhase];
  elements.chatInput.disabled = false;
  elements.chatForm.querySelector("button").disabled = false;
  setArtifactStatus("working", "成果物を生成しています");
  renderPhaseStepper();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

async function generateArtifact({ input, phase, parentArtifact = null }) {
  const previousDirectionId = state.selectedDirectionId;
  state.isBusy = true;
  setArtifactStatus("working", `${phaseLabels[phase]}を生成しています`);
  elements.previewLoading.hidden = false;
  elements.artifactPreview.hidden = true;
  elements.phaseActions.hidden = true;

  try {
    const result = await adapter.generate({
      sessionId: state.session.id,
      phase,
      input,
      parentArtifact,
      selectedDirection: selectedDirection(),
    });
    const artifact = materializeArtifact(result?.artifact, input);
    if (!artifact?.html) throw new Error("成果物のHTMLまたは構造データが返されませんでした。");
    state.artifact = artifact;
    state.artifactsByPhase[phase] = artifact;
    applyUsage(result.usage);
    state.currentPhase = phase;
    const directions = artifactDirections();
    state.selectedDirectionId =
      artifact.selectedDirectionId ||
      (parentArtifact ? previousDirectionId : null) ||
      (directions.length === 1 ? directions[0].id : null);
    renderArtifactHtml(artifact.html);
    elements.previewLoading.hidden = true;
    elements.phaseActions.hidden = false;
    setArtifactStatus("ready", adapter.mode === "local" ? "ローカル生成が完了しました" : "生成が完了しました");
    elements.openPreview.disabled = false;
    elements.downloadArtifact.disabled = false;
    elements.chatPhase.textContent = phaseLabels[phase];
    appendMessage("agent", result.message || `${phaseLabels[phase]}を作成しました。画面を確認し、左のチャットから修正を指示できます。`);
    renderPhaseStepper();
    renderNextPhaseActions();
    updateDraftControls();
  } finally {
    state.isBusy = false;
    renderPhaseStepper();
  }
}

async function sendChatMessage(event) {
  event.preventDefault();
  const message = elements.chatInput.value.trim();
  if (!message || state.isBusy) return;
  elements.chatInput.value = "";
  appendMessage("user", message);

  if (!state.session) {
    const promptField = document.querySelector("#prompt");
    promptField.value = promptField.value.trim()
      ? `${promptField.value.trim()}\n${message}`
      : message;
    appendMessage("agent", "依頼内容へ反映しました。右側で成果物の種類と画面サイズを確認し、「この内容で制作を開始」を押してください。");
    promptField.focus();
    return;
  }

  setChatBusy(true);

  try {
    const result = await adapter.sendMessage({
      sessionId: state.session.id,
      message,
      phase: state.currentPhase,
      artifact: state.artifact,
      input: state.session.input,
    });
    const artifact = materializeArtifact(result?.artifact, state.session.input);
    if (artifact?.html) {
      state.artifact = artifact;
      state.artifactsByPhase[state.currentPhase] = artifact;
      discardFollowingPhases(state.currentPhase);
      renderArtifactHtml(artifact.html);
      setArtifactStatus("ready", "修正版を表示しています");
      renderNextPhaseActions();
    }
    applyUsage(result?.usage);
    appendMessage("agent", result?.message || "依頼を受け付けました。");
    updateDraftControls();
  } catch (error) {
    appendMessage("agent", `処理できませんでした。${error.message || ""}`);
  } finally {
    setChatBusy(false);
  }
}

async function advancePhase(targetPhase) {
  if (!state.artifact || state.isBusy) return;
  const direction = selectedDirection();
  if (state.currentPhase === "wireframe" && !state.artifact.isConsolidated) {
    showToast("ワイヤー案を1案にまとめてから次へ進んでください。", true);
    return;
  }
  const sourcePhase = phaseLabels[state.currentPhase];
  const targetLabel = phaseLabels[targetPhase];
  const directionLabel = direction?.label || "現在の案";
  appendMessage("user", `${sourcePhase}の「${directionLabel}」をもとに、${targetLabel}へ進めてください。`);
  appendMessage("agent", `選定した1案と元資料、チャットを引き継ぎ、${targetLabel}を準備します。再アップロードは不要です。`);
  await generateArtifact({
    input: state.session.input,
    phase: targetPhase,
    selectedDirection: direction,
    parentArtifact: {
      id: state.artifact.id,
      phase: state.currentPhase,
      html: state.artifact.html,
      flowModel: state.artifact.flowModel || null,
      selectedDirectionId: direction?.id || null,
      isConsolidated: true,
    },
  });
}

async function consolidateDirection() {
  if (!state.artifact || state.isBusy) return;
  const direction = selectedDirection();
  if (!direction) {
    showToast("ベースにする案を1つ選択してください。", true);
    return;
  }

  appendMessage("user", `${direction.label}をベースに、ここまでの追加希望を反映してワイヤーを1案にまとめてください。`);
  appendMessage("agent", "選択した方向とチャットの内容を統合しています。まとまったワイヤーを確認後、UIモックアップまたはプロトタイプへ進めます。");
  setChatBusy(true);
  setArtifactStatus("working", "ワイヤー案を一本化しています");
  elements.phaseActions.hidden = true;

  try {
    const result = await adapter.consolidate({
      sessionId: state.session.id,
      input: state.session.input,
      artifact: state.artifact,
      selectedDirection: direction,
    });
    const artifact = materializeArtifact(result?.artifact, state.session.input);
    if (!artifact?.html) throw new Error("一本化した成果物のHTMLまたは構造データが返されませんでした。");
    state.artifact = artifact;
    state.artifactsByPhase.wireframe = artifact;
    discardFollowingPhases("wireframe");
    state.selectedDirectionId = artifact.selectedDirectionId || direction.id;
    applyUsage(result.usage);
    renderArtifactHtml(artifact.html);
    setArtifactStatus("ready", "最終ワイヤーを表示しています");
    appendMessage("agent", result.message || "ワイヤーを1案にまとめました。内容を確認し、次のフェーズへ進めます。");
    elements.phaseActions.hidden = false;
    renderNextPhaseActions();
    updateDraftControls();
  } catch (error) {
    appendMessage("agent", `一本化できませんでした。${error.message || ""}`);
    setArtifactStatus("error", "一本化に失敗しました");
    elements.phaseActions.hidden = false;
    renderNextPhaseActions();
  } finally {
    setChatBusy(false);
  }
}

function renderNextPhaseActions() {
  const mockupButton = document.querySelector('[data-next-phase="ui-mockup"]');
  const prototypeButton = document.querySelector('[data-next-phase="prototype"]');
  const directions = artifactDirections();
  const requiresConsolidation =
    state.currentPhase === "wireframe" &&
    directions.length > 1 &&
    !state.artifact?.isConsolidated;

  elements.phaseActions.hidden = state.currentPhase === "prototype";
  if (state.currentPhase === "prototype") return;

  elements.directionSelector.hidden = !requiresConsolidation;
  elements.consolidateDirection.hidden = !requiresConsolidation;
  elements.phaseActionButtons.hidden = requiresConsolidation;
  elements.phaseActionTitle.textContent = requiresConsolidation
    ? "比較案から最終ワイヤーをまとめる"
    : state.currentPhase === "wireframe"
      ? "ワイヤー案がまとまりました"
      : "この案を次のフェーズへ";
  elements.phaseActionNote.textContent = requiresConsolidation
    ? "1a／1bなどを比較し、ベース案を選んでください。追加希望はチャットで伝えてから、1案に一本化します。"
    : "元資料、依頼内容、チャット、現在の成果物を同じセッションのまま引き継ぎます。";
  elements.directionSelector.innerHTML = requiresConsolidation
    ? directions
        .map(
          (direction) => `
            <label class="direction-option">
              <input type="radio" name="selectedDirection" value="${escapeHtml(direction.id)}" ${direction.id === state.selectedDirectionId ? "checked" : ""}>
              <span>${escapeHtml(direction.label)}</span>
            </label>
          `,
        )
        .join("")
    : "";

  for (const input of elements.directionSelector.querySelectorAll('input[name="selectedDirection"]')) {
    input.addEventListener("change", () => {
      switchDirectionArtifact(input.value);
    });
  }
  mockupButton.hidden = state.currentPhase !== "wireframe";
  prototypeButton.hidden = false;
  updatePhaseButtonState();
}

function updatePhaseButtonState() {
  const requiresConsolidation =
    state.currentPhase === "wireframe" &&
    artifactDirections().length > 1 &&
    !state.artifact?.isConsolidated;
  elements.consolidateDirection.disabled = requiresConsolidation && !selectedDirection();
  const disabled = state.currentPhase === "wireframe" && !state.artifact?.isConsolidated;
  for (const button of document.querySelectorAll("[data-next-phase]")) {
    button.disabled = disabled;
  }
}

function artifactDirections() {
  return Array.isArray(state.artifact?.directions) ? state.artifact.directions : [];
}

function selectedDirection() {
  return artifactDirections().find((direction) => direction.id === state.selectedDirectionId) || null;
}

function switchDirectionArtifact(directionId) {
  const direction = artifactDirections().find((item) => item.id === directionId);
  if (!direction) return;
  state.selectedDirectionId = directionId;
  if (direction.flowModel) {
    const materialized = materializeArtifact(
      {
        ...state.artifact,
        selectedDirectionId: directionId,
        flowModel: direction.flowModel,
      },
      state.session?.input || {},
    );
    state.artifact = materialized;
    state.artifactsByPhase.wireframe = materialized;
    renderArtifactHtml(materialized.html);
    setArtifactStatus("ready", `${direction.label}を表示しています`);
  }
  updatePhaseButtonState();
  updateDraftControls();
}

function renderPhaseStepper() {
  const order = ["wireframe", "ui-mockup", "prototype"];
  const currentIndex = order.indexOf(state.currentPhase);
  for (const item of document.querySelectorAll("[data-phase-step]")) {
    const index = order.indexOf(item.dataset.phaseStep);
    const button = item.querySelector("[data-phase-target]");
    const available = Boolean(state.artifactsByPhase[item.dataset.phaseStep]);
    item.classList.toggle("is-current", index === currentIndex);
    item.classList.toggle("is-complete", index < currentIndex);
    item.classList.toggle("is-available", available);
    button.disabled = !available || index === currentIndex || state.isBusy;
    button.setAttribute(
      "aria-label",
      index === currentIndex
        ? `${phaseLabels[item.dataset.phaseStep]}を表示中`
        : `${phaseLabels[item.dataset.phaseStep]}へ戻る`,
    );
  }
}

function restorePhase(targetPhase) {
  const artifact = state.artifactsByPhase[targetPhase];
  if (!artifact || state.isBusy || targetPhase === state.currentPhase) return;
  state.currentPhase = targetPhase;
  state.artifact = artifact;
  state.selectedDirectionId = artifact.selectedDirectionId || null;
  renderArtifactHtml(artifact.html);
  elements.previewLoading.hidden = true;
  elements.artifactPreview.hidden = false;
  elements.phaseActions.hidden = false;
  elements.openPreview.disabled = false;
  elements.downloadArtifact.disabled = false;
  elements.chatPhase.textContent = phaseLabels[targetPhase];
  setArtifactStatus("ready", `${phaseLabels[targetPhase]}へ戻りました`);
  renderPhaseStepper();
  renderNextPhaseActions();
  updateDraftControls();
  const messages = {
    wireframe: "ワイヤーへ戻りました。ここで修正すると、UIモックとプロトタイプは作り直しになります。",
    "ui-mockup": "UIモックへ戻りました。ワイヤーは保持されます。ここで修正すると、プロトタイプは作り直しになります。",
    prototype: "プロトタイプへ戻りました。前フェーズの成果物は保持されています。操作確認を続けられます。",
  };
  showToast(messages[targetPhase] || `${phaseLabels[targetPhase]}へ戻りました。`);
}

function discardFollowingPhases(phase) {
  const order = ["wireframe", "ui-mockup", "prototype"];
  const index = order.indexOf(phase);
  for (const laterPhase of order.slice(index + 1)) delete state.artifactsByPhase[laterPhase];
  renderPhaseStepper();
}

function setArtifactStatus(status, label) {
  elements.artifactStatus.textContent = status === "ready" ? "確認可能" : status === "error" ? "エラー" : "制作中";
  elements.artifactLabel.textContent = label;
}

function setChatBusy(busy) {
  state.isBusy = busy;
  elements.chatInput.disabled = busy;
  elements.chatForm.querySelector("button").disabled = busy;
  renderPhaseStepper();
}

function appendMessage(role, text) {
  const article = document.createElement("article");
  article.className = `chat-message is-${role}`;
  if (role === "agent") {
    article.innerHTML = `<span class="message-avatar" aria-hidden="true">${agentIconMarkup()}</span><div><strong>AI Product Designer</strong><p></p></div>`;
  } else {
    article.innerHTML = "<div><p></p></div>";
  }
  article.querySelector("p").textContent = text;
  elements.chatMessages.append(article);
  elements.chatMessages.scrollTop = elements.chatMessages.scrollHeight;
}

function renderArtifactHtml(html) {
  const current = elements.artifactPreview;
  const next = current.cloneNode(false);
  next.srcdoc = html;
  next.hidden = false;
  current.replaceWith(next);
  elements.artifactPreview = next;
}

function materializeArtifact(artifact, input) {
  if (!artifact) return artifact;
  if (artifact.phase !== "wireframe" || input.outputLevel !== "structural-wireframe") {
    return artifact;
  }
  const renderer = window.AIProductDesignerArtifactRenderer;
  if (!renderer?.structuralFlowHtml) return artifact;
  const demoFlowFactory = window.AIProductDesignerDemoFlowModel;
  const directions = Array.isArray(artifact.directions)
    ? artifact.directions.map((direction) => ({
        ...direction,
        flowModel:
          direction.flowModel ||
          (typeof demoFlowFactory === "function" && input.outputLevel === "structural-wireframe"
            ? demoFlowFactory(input, direction.id)
            : null),
      }))
    : [];
  const activeDirection =
    directions.find((direction) => direction.id === artifact.selectedDirectionId) ||
    directions[0] ||
    null;
  const flowModel =
    activeDirection?.flowModel ||
    artifact.flowModel ||
    extractEmbeddedFlowModel(artifact.html);
  if (!flowModel) return artifact;
  return {
    ...artifact,
    directions,
    flowModel,
    html: renderer.structuralFlowHtml({
      input,
      model: flowModel,
      consolidated: Boolean(artifact.isConsolidated),
    }),
    rendererVersion: 2,
  };
}

function extractEmbeddedFlowModel(html) {
  if (typeof html !== "string" || !html.includes('id="flow-model"')) return null;
  try {
    const document = new DOMParser().parseFromString(html, "text/html");
    const model = JSON.parse(document.querySelector("#flow-model")?.textContent || "null");
    if (!Array.isArray(model?.screens) || !Array.isArray(model?.edges)) return null;
    return model;
  } catch {
    return null;
  }
}

function receiveArtifactEdit(event) {
  if (
    event.source !== elements.artifactPreview.contentWindow ||
    event.data?.type !== "ai-product-designer:artifact-updated" ||
    typeof event.data.html !== "string" ||
    !event.data.html.startsWith("<!doctype html>")
  ) {
    return;
  }
  const flowModel = extractEmbeddedFlowModel(event.data.html) || state.artifact.flowModel;
  const directions = artifactDirections().map((direction) =>
    direction.id === state.selectedDirectionId
      ? { ...direction, flowModel }
      : direction,
  );
  state.artifact = {
    ...state.artifact,
    html: event.data.html,
    flowModel,
    directions,
    selectedDirectionId: state.selectedDirectionId,
    editedLocally: true,
    updatedAt: new Date().toISOString(),
  };
  state.artifactsByPhase[state.currentPhase] = state.artifact;
  discardFollowingPhases(state.currentPhase);
  setArtifactStatus("ready", "直接編集を反映しました");
  updateDraftControls();
}

function toggleChat() {
  const open = elements.appShell.classList.toggle("is-chat-open");
  for (const button of document.querySelectorAll("[data-chat-toggle]")) {
    button.setAttribute("aria-expanded", String(open));
  }
}

function openArtifact() {
  if (!state.artifact?.html) return;
  const url = URL.createObjectURL(new Blob([state.artifact.html], { type: "text/html;charset=utf-8" }));
  window.open(url, "_blank", "noopener,noreferrer");
  window.setTimeout(() => URL.revokeObjectURL(url), 60000);
}

function downloadArtifact() {
  if (!state.artifact?.html) return;
  const url = URL.createObjectURL(new Blob([state.artifact.html], { type: "text/html;charset=utf-8" }));
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = state.artifact.filename || `${state.currentPhase}.html`;
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
  showToast("HTMLをダウンロードしました。");
}

function resetSession() {
  state.session = null;
  state.artifact = null;
  state.artifactsByPhase = {};
  state.isBusy = false;
  state.currentPhase = "wireframe";
  state.selectedDirectionId = null;
  state.tokenTotal = 0;
  state.evidenceFiles = [];
  state.designSystemFiles = [];
  state.evidenceBatchId = crypto.randomUUID();
  elements.requestForm.reset();
  document.querySelector('[name="outputLevel"][value="structural-wireframe"]').checked = true;
  document.querySelector('[name="viewport"][value="390x844"]').checked = true;
  document.querySelector('[name="viewport"][value="1440x1000"]').checked = true;
  elements.artifactPreview.srcdoc = "";
  elements.workspaceView.hidden = true;
  elements.intakeView.hidden = false;
  elements.chatContext.hidden = true;
  elements.chatInput.value = "";
  elements.chatInput.disabled = false;
  elements.chatForm.querySelector("button").disabled = false;
  elements.openPreview.disabled = true;
  elements.downloadArtifact.disabled = true;
  renderTokenUsage();
  resetChatMessages();
  updateDraftControls();
  renderAttachmentFiles("design-system");
  renderAttachmentFiles("reference");
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function resetChatMessages() {
  elements.chatMessages.innerHTML = "";
  appendMessage(
    "agent",
    "依頼内容と参考資料を入力してください。作成後は、同じ案を見ながら修正や次のフェーズを相談できます。",
  );
}

function attachmentFiles(kind) {
  return kind === "design-system" ? state.designSystemFiles : state.evidenceFiles;
}

function setAttachmentFiles(kind, files) {
  if (kind === "design-system") state.designSystemFiles = files;
  else state.evidenceFiles = files;
}

function addAttachmentFiles(kind, entries) {
  const byPath = new Map(attachmentFiles(kind).map((item) => [item.relativePath, item]));
  for (const entry of entries) {
    if (!entry?.file || entry.file.size === 0 || entry.file.size > 50 * 1024 * 1024) {
      if (entry?.file?.size === 0) showToast(`${entry.file.name} は空のファイルです。`, true);
      if (entry?.file?.size > 50 * 1024 * 1024) showToast(`${entry.file.name} は50MBを超えています。`, true);
      continue;
    }
    const relativePath = normalizeClientPath(entry.relativePath || entry.file.name);
    byPath.set(relativePath, {
      key: crypto.randomUUID(),
      file: entry.file,
      relativePath,
    });
  }
  setAttachmentFiles(kind, [...byPath.values()]);
  renderAttachmentFiles(kind);
}

function renderAttachmentFiles(kind) {
  const fileList = kind === "design-system" ? elements.designSystemFileList : elements.evidenceFileList;
  fileList.innerHTML = attachmentFiles(kind)
    .map(
      (item) => `
        <div class="evidence-file-item">
          <span class="file-kind">${escapeHtml(extensionOf(item.file.name).replace(".", "") || "file")}</span>
          <span><strong>${escapeHtml(item.file.name)}</strong><small>${escapeHtml(item.relativePath)}</small></span>
          <span class="evidence-file-size">${formatBytes(item.file.size)}</span>
          <button type="button" data-remove-attachment="${escapeHtml(item.key)}" aria-label="${escapeHtml(item.file.name)}を削除">×</button>
        </div>
      `,
    )
    .join("");
}

function attachmentSummary(item, category) {
  return {
    category,
    name: item.file.name,
    relativePath: item.relativePath,
    type: item.file.type || extensionOf(item.file.name),
    size: item.file.size,
  };
}

async function uploadAttachmentFiles() {
  const uploaded = { designSystem: [], reference: [] };
  for (const group of [
    { kind: "design-system", target: uploaded.designSystem },
    { kind: "reference", target: uploaded.reference },
  ]) {
    for (const item of attachmentFiles(group.kind)) {
      const storedPath = `${group.kind}/${item.relativePath}`;
      const response = await fetch(
        `/api/reference-files?batch=${encodeURIComponent(state.evidenceBatchId)}&path=${encodeURIComponent(storedPath)}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/octet-stream" },
          body: item.file,
        },
      );
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || `${item.file.name}を保存できませんでした。`);
      group.target.push({ ...data, category: group.kind });
    }
  }
  return uploaded;
}

async function filesFromDataTransfer(dataTransfer) {
  const entries = [...(dataTransfer?.items || [])].map((item) => item.webkitGetAsEntry?.()).filter(Boolean);
  if (!entries.length) {
    return [...(dataTransfer?.files || [])].map((file) => ({ file, relativePath: file.name }));
  }
  const files = [];
  for (const entry of entries) await collectDroppedEntry(entry, "", files);
  return files;
}

async function collectDroppedEntry(entry, parentPath, output) {
  const relativePath = normalizeClientPath(`${parentPath}/${entry.name}`);
  if (entry.isFile) {
    const file = await new Promise((resolve, reject) => entry.file(resolve, reject));
    output.push({ file, relativePath });
    return;
  }
  if (!entry.isDirectory) return;
  const reader = entry.createReader();
  while (true) {
    const children = await new Promise((resolve, reject) => reader.readEntries(resolve, reject));
    if (!children.length) break;
    for (const child of children) await collectDroppedEntry(child, relativePath, output);
  }
}

function normalizeClientPath(value) {
  return String(value).replaceAll("\\", "/").split("/").filter((part) => part && part !== "." && part !== "..").join("/");
}

function makeTitle(prompt) {
  const compact = prompt.replace(/\s+/g, " ").trim();
  return compact.length > 30 ? `${compact.slice(0, 30)}…` : compact;
}

function extensionOf(name) {
  const index = String(name).lastIndexOf(".");
  return index >= 0 ? String(name).slice(index).toLowerCase() : "";
}

function formatBytes(value) {
  if (value < 1024) return `${value} B`;
  if (value < 1024 * 1024) return `${Math.round(value / 1024)} KB`;
  return `${(value / (1024 * 1024)).toFixed(1)} MB`;
}

function showToast(message, error = false) {
  window.clearTimeout(toastTimer);
  elements.toast.textContent = message;
  elements.toast.classList.toggle("is-error", error);
  elements.toast.classList.add("is-visible");
  toastTimer = window.setTimeout(() => elements.toast.classList.remove("is-visible"), 2800);
}

function applyUsage(usage) {
  const amount = Number(usage?.totalTokens ?? usage?.total_tokens ?? 0);
  if (!Number.isFinite(amount) || amount <= 0) return;
  state.tokenTotal += Math.round(amount);
  renderTokenUsage();
}

function renderTokenUsage() {
  elements.tokenTotal.textContent = state.tokenTotal.toLocaleString("ja-JP");
}

function saveDraft() {
  if (!state.session || !state.artifact) return;
  const payload = {
    version: 1,
    savedAt: new Date().toISOString(),
    session: state.session,
    artifact: state.artifact,
    artifactsByPhase: state.artifactsByPhase,
    currentPhase: state.currentPhase,
    selectedDirectionId: state.selectedDirectionId,
    tokenTotal: state.tokenTotal,
    messages: [...elements.chatMessages.querySelectorAll(".chat-message")].map((message) => ({
      role: message.classList.contains("is-user") ? "user" : "agent",
      text: message.querySelector("p")?.textContent || "",
    })),
  };

  try {
    localStorage.setItem(draftStorageKey, JSON.stringify(payload));
    updateDraftControls();
    showToast("現在のやり取りと成果物をこのブラウザへ一時保存しました。");
  } catch (error) {
    showToast(`一時保存できませんでした。${error.message || ""}`, true);
  }
}

function restoreDraft() {
  const draft = readDraft();
  if (!draft?.session || (!draft?.artifact?.html && !draft?.artifact?.flowModel)) {
    showToast("復元できる一時保存がありません。", true);
    updateDraftControls();
    return;
  }
  if (state.session && !window.confirm("現在の制作を閉じて、一時保存した内容を復元しますか？")) return;

  state.session = draft.session;
  state.artifact = materializeArtifact(draft.artifact, draft.session.input || {});
  state.currentPhase = draft.currentPhase || draft.artifact.phase || "wireframe";
  state.artifactsByPhase = Object.fromEntries(
    Object.entries(draft.artifactsByPhase || { [state.currentPhase]: draft.artifact }).map(([phase, artifact]) => [
      phase,
      materializeArtifact(artifact, draft.session.input || {}),
    ]),
  );
  state.artifactsByPhase[state.currentPhase] = state.artifact;
  state.selectedDirectionId = draft.selectedDirectionId || draft.artifact.selectedDirectionId || null;
  state.tokenTotal = Number(draft.tokenTotal || 0);
  state.evidenceFiles = [];
  state.designSystemFiles = [];
  state.isBusy = false;

  const input = state.session.input || {};
  showWorkspace(input.title || "一時保存した制作", input.outputLevel || state.currentPhase);
  elements.chatMessages.innerHTML = "";
  for (const message of draft.messages || []) appendMessage(message.role, message.text);
  if (!draft.messages?.length) appendMessage("agent", "一時保存した制作を復元しました。");
  appendMessage("agent", "一時保存を復元しました。添付ファイル本体はブラウザへ保持されないため、再生成時に必要なら再添付してください。");
  renderArtifactHtml(state.artifact.html);
  elements.previewLoading.hidden = true;
  elements.phaseActions.hidden = false;
  elements.openPreview.disabled = false;
  elements.downloadArtifact.disabled = false;
  setArtifactStatus("ready", "一時保存した成果物を表示しています");
  renderTokenUsage();
  renderPhaseStepper();
  renderNextPhaseActions();
  updateDraftControls();
  showToast("一時保存した制作を復元しました。");
}

function readDraft() {
  try {
    return JSON.parse(localStorage.getItem(draftStorageKey) || "null");
  } catch {
    return null;
  }
}

function updateDraftControls() {
  const draft = readDraft();
  elements.saveDraft.disabled = !state.session || !state.artifact;
  elements.restoreDraft.disabled = !draft;
  elements.restoreDraft.classList.toggle("has-draft", Boolean(draft));
  elements.restoreDraft.title = draft?.savedAt
    ? `${new Date(draft.savedAt).toLocaleString("ja-JP")} に一時保存`
    : "一時保存はありません";
}

function agentIconMarkup() {
  return `<svg viewBox="0 0 32 32" focusable="false">
    <rect x="4.5" y="5.5" width="23" height="18" rx="2.5"></rect>
    <path d="M5 11h22M12 11v12"></path>
    <circle cx="8" cy="8.3" r=".8"></circle>
    <path class="avatar-cursor" d="m18 16 8 4.2-4.2 1.1-1.2 4.2L18 16Z"></path>
  </svg>`;
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}
